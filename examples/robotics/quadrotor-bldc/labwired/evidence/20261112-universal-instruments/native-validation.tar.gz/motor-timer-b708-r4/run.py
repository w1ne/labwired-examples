#!/usr/bin/env python3
"""Normal, isolated native validation of the frozen motor/timer R4 source."""
from pathlib import Path
import fcntl
import hashlib
import json
import os
import re
import subprocess
import sys
import time

SOURCE = Path('/data/worktrees/labwired-core-motor-timer-594a9931-20261112')
AUDIT = Path('/data/labwired-core-review-ready-20261112/motor-timer-b708-r4')
ENV = dict(os.environ)
ENV.update({
    'PATH': '/home/andrii/.cargo/bin:' + ENV.get('PATH', ''),
    'TMPDIR': '/data/work-scratch/core-bldc-service-594a9931',
    'CARGO_TARGET_DIR': '/data/build-targets/generic-594a9931-20261112',
    'CARGO_PROFILE_DEV_DEBUG': '0',
    'CARGO_PROFILE_TEST_DEBUG': '0',
    'CARGO_BUILD_JOBS': '2',
    'CARGO_INCREMENTAL': '0',
    'RUSTC_WRAPPER': '',
})
RESULTS = []


def run(name, command, test=False):
    print(f'starting {name}', flush=True)
    start = time.monotonic()
    with (AUDIT / f'{name}.log').open('w') as output:
        completed = subprocess.run(command, cwd=SOURCE, env=ENV, stdout=output, stderr=subprocess.STDOUT)
    status = completed.returncode
    result = {'name': name, 'exit': status, 'seconds': time.monotonic() - start, 'command': command}
    if test:
        log = (AUDIT / f'{name}.log').read_text()
        counts = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;', log)
        result['passed'] = sum(int(passed) for passed, _ in counts)
        result['failed'] = sum(int(failed) for _, failed in counts)
        if status == 0 and (not counts or result['passed'] == 0):
            status = 1
            result['exit'] = status
            result['error'] = 'required test group executed no passing tests'
    (AUDIT / f'{name}.exit').write_text(f'{status}\n')
    RESULTS.append(result)
    (AUDIT / 'steps.json').write_text(json.dumps(RESULTS, indent=2) + '\n')
    print(f'finished {name} exit {status}', flush=True)
    return status


def verify(receipt):
    actual = {name: hashlib.sha256((SOURCE / name).read_bytes()).hexdigest() for name in receipt['files']}
    for name, expected in receipt['files'].items():
        if actual[name] != expected:
            raise RuntimeError(f'frozen source changed: {name}')
    return actual


def main():
    lock = open('/data/labwired-core-review-ready-20261112/motor-timer-b708-r1/job.lock', 'w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    receipt = json.loads((AUDIT / 'source-receipt.json').read_text())
    stat = os.statvfs('/data')
    free = stat.f_bavail * stat.f_frsize
    print(f'disk preflight free bytes: {free}', flush=True)
    if free < 6 * 1024**3:
        raise RuntimeError('unchanged 6 GiB preflight floor')
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip()
    if head != receipt['base']:
        raise RuntimeError(f'base changed: {head}')
    verify(receipt)
    (AUDIT / 'preflight.json').write_text(json.dumps({'freeBytes': free, 'head': head, 'verifiedFiles': len(receipt['files'])}, indent=2) + '\n')
    if run('fmt', ['cargo', 'fmt', '--all', '--', '--check']):
        return 1
    core = ['cargo', 'test', '-p', 'labwired-core', '--features', 'event-scheduler']
    if run('compile', core + ['--lib', '--test', 'stm32_v2_timer_output_pad', '--test', 'logic_capture_late_drive', '--test', 'stm32_timer_walk_differential', '--no-run']):
        return 1
    groups = [
        ('numeric', ['--lib', 'live_numeric::tests', '--', '--nocapture']),
        ('motor', ['--lib', 'bus::motors::tests', '--', '--nocapture']),
        ('motor_boundary', ['--lib', 'bus::tests::bus_motor_bldc_samples_tim1_six_gates_and_is_deterministic', '--', '--exact', '--nocapture']),
        ('motor_physics', ['--lib', 'physics::motor', '--', '--nocapture']),
        ('timer', ['--lib', 'peripherals::timer', '--', '--nocapture']),
        ('ledc', ['--lib', 'peripherals::esp_ledc_wave::tests', '--', '--nocapture']),
        ('gpio', ['--lib', 'peripherals::gpio::stm32_af_idr_tests', '--', '--nocapture']),
        ('logic_existing', ['--lib', 'tests::logic_capture', '--', '--nocapture']),
        ('late_drive', ['--test', 'logic_capture_late_drive', '--', '--nocapture']),
        ('pads', ['--test', 'stm32_v2_timer_output_pad', '--', '--nocapture']),
        ('timer_walk', ['--test', 'stm32_timer_walk_differential', '--', '--nocapture']),
    ]
    failures = sum(bool(run(name, core + args, test=True)) for name, args in groups)
    (AUDIT / 'native-tests.exit').write_text(f'{int(failures > 0)}\n')
    actual = verify(receipt)
    (AUDIT / 'source-after-native.json').write_text(json.dumps(actual, indent=2) + '\n')
    if failures:
        return 1
    return run('precommit', ['bash', 'scripts/pre-commit.sh'])


if __name__ == '__main__':
    status = 1
    try:
        status = main()
    finally:
        receipt = json.loads((AUDIT / 'source-receipt.json').read_text())
        (AUDIT / 'source-after-run.json').write_text(json.dumps(verify(receipt), indent=2) + '\n')
        (AUDIT / 'pipeline.exit').write_text(f'{status}\n')
    sys.exit(status)
