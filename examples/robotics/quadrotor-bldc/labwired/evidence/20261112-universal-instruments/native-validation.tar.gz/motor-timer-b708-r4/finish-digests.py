from pathlib import Path
import subprocess
p=Path(__file__).parent
with (p/'digests.log').open('w') as out:
 result=subprocess.run(['python3','scripts/generate_validation_status.py','--digests'],cwd='/data/worktrees/labwired-core-motor-timer-594a9931-20261112',stdout=out,stderr=subprocess.STDOUT)
(p/'digests.exit').write_text(str(result.returncode)+'\n')
