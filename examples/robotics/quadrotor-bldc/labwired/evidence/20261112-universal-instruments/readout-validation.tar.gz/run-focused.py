from pathlib import Path
import subprocess,os,json,time,concurrent.futures
app=Path('/data/worktrees/labwired-analog-scope-series-20261112')
out=Path('/data/work-evidence/logic-late-state-594a9931-20261112')
env=os.environ.copy();env['PATH']='/home/andrii/.nvm/versions/node/v22.23.4/bin:'+env['PATH'];env['TMPDIR']='/data/work-scratch/universal-instruments-20261112/tmp'
def run(name,args,cwd=app):
 with (out/(name+'.log')).open('wb') as log:r=subprocess.run(args,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 (out/(name+'.exit')).write_text(str(r.returncode)+'\n')
 print(name,r.returncode,flush=True)
 return {'name':name,'exit':r.returncode}
def types():
 return [run('type-app',[str(app/'node_modules/.bin/tsc'),'-b'],app/'packages/playground'),run('type-tests',['npm','-w','packages/playground','run','typecheck:tests'])]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 jobs=[pool.submit(run,'focused',['npm','-w','packages/playground','run','test','--','src/instruments/logicEdgeCapture.test.ts','src/instruments/LogicAnalyzerPanel.test.tsx','src/function-size.test.ts']),pool.submit(run,'lint',['npm','-w','packages/playground','run','lint']),pool.submit(types)]
 results=[job.result() for job in jobs]
(out/'validation-summary.json').write_text(json.dumps({'completed_at_epoch_s':time.time(),'results':results},indent=2)+'\n')
