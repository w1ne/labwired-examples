#!/usr/bin/env python3
"""Supplement the frozen native audit with actual paused LA DOM readouts.

Reads captured evidence only. A missing DOM receipt cannot pass. Native state
is reconstructed only within the last watch epoch mapping every selected lane
on that owner, through that epoch's own Boolean/four-state common horizon.
"""
import argparse
import hashlib
import json
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def identity(query):
    req = query.get('request', {})
    return (query.get('worker'), query.get('chip'), req.get('watchEpoch'))


def signal(ref):
    if ref.get('kind') == 'gpio':
        return ('gpio', ref.get('peripheral'), ref.get('pin'))
    return ('wire', ref.get('peripheral'), ref.get('line'))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('receipts', type=Path)
    parser.add_argument('--expected-wasm-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    root = args.receipts.resolve()
    native_path = root / 'independent-native-audit.json'
    native = read(native_path)
    assert native['verdict'] == 'pass', 'Native runtime audit did not pass'
    wasm = read(root / 'wasm-provenance.json')
    assert wasm['expectedSha256'] == args.expected_wasm_sha256
    assert wasm['preflight']['sha256'] == args.expected_wasm_sha256
    first, second = [read(root / (name + '.json')) for name in
                     ('paused-clock-first', 'paused-clock-and-retention')]
    for name in ('paused-clock-first.json', 'paused-clock-and-retention.json',
                 'result.json', 'wasm-provenance.json'):
        assert digest(root / name) == native['inputSha256'][name]
    pause = next(mark for mark in read(root / 'result.json')['marks']
                 if mark['name'] == 'paused-clock-window-observed')
    assert pause['firstCycles'] == pause['secondCycles']
    assert set(pause['secondCycles']) == {'ctrl1', 'ctrl2', 'ctrl3', 'ctrl4'}
    ui = second['uiSnapshot']
    assert ui['latestControllerCycles'] == pause['secondCycles']
    assert first['uiSnapshot']['latestControllerCycles'] == pause['secondCycles']
    assert second['audit']['digitalHistoryOmitted'] == 0, 'Passive digital history is incomplete'
    rows = ui['logicChannels']
    assert {row['channel'] for row in rows} == {'CH0', 'CH1', 'CH2', 'CH3'}
    owner_refs = {}
    selected = {}
    for row in rows:
        key = json.loads(row['ownerSignal'])
        assert key[1] == 'digital' and key[2] in ('gpio', 'wire')
        owner, ref = key[0], tuple(key[2:])
        assert owner in pause['secondCycles']
        owner_refs.setdefault(owner, set()).add(ref)
        selected[row['channel']] = (owner, ref)
    batches = second['audit']['digitalBatches'] + list(second['audit']['queries'].values())
    unique = {}
    for query in batches:
        request = query.get('request', {})
        unique[(*identity(query), request.get('method'), query.get('response', {}).get('id'))] = query
    batches = list(unique.values())
    epochs = {}
    for owner, refs in owner_refs.items():
        watches = [query for query in batches if query.get('chip') == owner
                   and query['request']['method'] == 'watchLogicSignals'
                   and isinstance(query.get('response', {}).get('value'), list)
                   and refs <= {signal(ref) for ref in query['response']['value']}]
        assert watches, f'No native watch maps selected owner {owner}'
        watch = max(watches, key=lambda query: (query['wallMs'], query['request']['watchEpoch']))
        epoch = identity(watch)
        streams = {}
        for method in ('readLogicEdges', 'readLogicStates'):
            records = [query for query in batches if identity(query) == epoch
                       and query['request']['method'] == method]
            assert records, f'Missing native {method} in selected epoch'
            assert all(query['response']['value']['dropped'] == 0 for query in records)
            assert all(query['wallMs'] >= query['request']['sentAtMs'] for query in records)
            streams[method] = max(records, key=lambda query: (query['wallMs'],
                                  query['response']['value']['nowCycle'],
                                  query['response']['value']['cursor']))['response']['value']
            spans = sorted((query['response']['value']['cursor'] - len(query['response']['value']['edges']),
                            query['response']['value']['cursor']) for query in records
                           if query['response']['value']['edges'])
            covered = 0
            for start, end in spans:
                assert 0 <= start <= end and start <= covered, 'Native cursor history has a gap'
                covered = max(covered, end)
            assert covered == streams[method]['cursor'], 'Native cursor tail is incomplete'
        horizon = min(streams['readLogicEdges']['nowCycle'], streams['readLogicStates']['nowCycle'])
        assert 0 <= horizon <= pause['secondCycles'][owner]
        state_events = {}
        for query in batches:
            if identity(query) != epoch or query['request']['method'] != 'readLogicStates':
                continue
            value = query['response']['value']
            for index, event in enumerate(value['edges']):
                ordinal = value['cursor'] - len(value['edges']) + index
                if ordinal in state_events:
                    assert state_events[ordinal] == event
                state_events[ordinal] = event
        epochs[owner] = (watch, streams, horizon, sorted(state_events.items()))
    evidence = []
    for row in rows:
        owner, ref = selected[row['channel']]
        watch, streams, horizon, events = epochs[owner]
        native_channel = next(item['ch'] for item in watch['response']['value'] if signal(item) == ref)
        initial = streams['readLogicStates']['initial'][native_channel]
        state, last_event = initial, None
        for ordinal, event in events:
            if event['ch'] == native_channel and event['cycle'] <= horizon:
                state, last_event = event['state'], {**event, 'ordinal': ordinal}
        assert state in ('0', '1', 'z', 'x'), 'No known native state at the held horizon'
        expected_badge = state.upper()
        expected_summary = {'0': 'LOW', '1': 'HIGH', 'z': 'Z', 'x': 'X'}[state]
        assert row['badgeText'] == expected_badge, f"{row['channel']} badge/native mismatch"
        assert row['summaryLevelText'] == expected_summary, f"{row['channel']} summary/native mismatch"
        assert row['waveformAttributes']['data-four-state'] == 'true'
        if state == 'z':
            assert row['highZRegions'], 'Visible Z readout lacks a rendered high-impedance region'
        evidence.append({'channel': row['channel'], 'sourceId': owner, 'signal': list(ref),
                         'worker': identity(watch)[0], 'watchEpoch': identity(watch)[2],
                         'nativeInitialState': initial, 'nativeStateAtHorizon': state,
                         'nativeCommonHorizonCycles': horizon,
                         'nativeBooleanHorizonCycles': streams['readLogicEdges']['nowCycle'],
                         'nativeFourStateHorizonCycles': streams['readLogicStates']['nowCycle'],
                         'pausedCpuCycles': pause['secondCycles'][owner], 'lastNativeStateEvent': last_event,
                         'badgeText': row['badgeText'], 'summaryLevelText': row['summaryLevelText'],
                         'renderedFourState': True, 'renderedHighZRegions': len(row['highZRegions'])})
    assert any(row['nativeStateAtHorizon'] == 'z' for row in evidence), 'No actual Z readout was captured'
    report = {'verdict': 'pass', 'kind': 'paused_native_to_dom_readout_comparison',
              'sourceReceipt': str(root / 'paused-clock-and-retention.json'),
              'sourceReceiptSha256': digest(root / 'paused-clock-and-retention.json'),
              'nativeAuditReportSha256': digest(native_path),
              'expectedWasmSha256': args.expected_wasm_sha256,
              'auditorSha256': digest(Path(__file__)), 'channels': evidence,
              'limits': ['This compares retained native evidence to actual captured DOM. Screenshot review is separate.',
                         'Unknown-before-first behavior and X rendering require their executed regression tests; this capture does not manufacture either state.']}
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
