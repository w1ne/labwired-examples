// R4-labels: adds passive DOM readouts to existing atomic receipts only.
// R4-video: unchanged R4 proof, then a normal-UI four-second circuit shot.
// R4: live numeric cursor evidence; R3/8842 remains a frozen negative control.
// Extends the existing real-app quadrotor probe: passive receipts, actual UI,
// original hosted firmware compilation. No response or waveform replacement.
import { chromium } from '/home/andrii/projects/labwired/node_modules/playwright/index.mjs';
import fs from 'node:fs/promises';
import { createHash } from 'node:crypto';

const origin = process.env.QUAD_APP_ORIGIN ?? 'http://127.0.0.1:5193';
const dir = process.env.QUAD_ACCEPTANCE_DIR ?? '/data/work-evidence/quadrotor-public-browser-20261112/instrument-branch';
const projectId = '7c92d38a4f2ac205aa91502291fde0d8';
const expectedWasmSha256 = process.env.QUAD_EXPECTED_WASM_SHA256?.toLowerCase();
if (!/^[a-f0-9]{64}$/.test(expectedWasmSha256 ?? '')) throw Error('QUAD_EXPECTED_WASM_SHA256 must name the frozen candidate engine');
await fs.mkdir(dir, { recursive: true });
const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', headless: true, args: [
  '--no-sandbox', '--disable-dev-shm-usage', '--enable-webgl', '--enable-unsafe-swiftshader',
  '--use-gl=angle', '--use-angle=swiftshader', '--disable-background-timer-throttling', '--disable-renderer-backgrounding',
] });
const context = await browser.newContext({ viewport: { width: 1600, height: 900 }, acceptDownloads: true,
  ...(process.env.QUAD_RECORD_VIDEO === '1' ? { recordVideo: { dir, size: { width: 1600, height: 900 } } } : {}),
});
const wasmAudit = { expectedSha256: expectedWasmSha256, preflight: null, browserResponses: [], errors: [] };
const wasmResponseTasks = new Set();
const saveWasmAudit = () => fs.writeFile(`${dir}/wasm-provenance.json`, JSON.stringify(wasmAudit, null, 2));
// Passive response observation only: no route handler or response replacement.
context.on('response', response => {
  if (!/\/labwired_wasm_bg(?:\.[a-f0-9]+)?\.wasm(?:\?|$)/i.test(response.url())) return;
  const task = (async () => {
    const body = await response.body();
    const observed = { wallMs: Date.now(), url: response.url(), status: response.status(),
      bytes: body.length, sha256: createHash('sha256').update(body).digest('hex'),
      fromServiceWorker: response.fromServiceWorker() };
    wasmAudit.browserResponses.push(observed);
    if (!response.ok() || observed.sha256 !== expectedWasmSha256) wasmAudit.errors.push(`Browser engine identity mismatch: ${observed.url}`);
  })().catch(error => wasmAudit.errors.push(`Could not read browser engine response: ${error.message}`))
    .finally(() => wasmResponseTasks.delete(task));
  wasmResponseTasks.add(task);
});
try {
  // Dev uses this flat asset name. A production recapture may supply its
  // content-hashed URL explicitly; the expected bytes are always mandatory.
  const requestedUrl = new URL(process.env.QUAD_ENGINE_WASM_URL ?? '/wasm/labwired_wasm_bg.wasm', origin).href;
  const response = await context.request.get(requestedUrl);
  const body = await response.body();
  wasmAudit.preflight = { wallMs: Date.now(), requestedUrl, url: response.url(), status: response.status(),
    bytes: body.length, sha256: createHash('sha256').update(body).digest('hex'),
    contentType: response.headers()['content-type'] ?? null, beforeAnyFirmwareInit: true };
  await saveWasmAudit();
  if (!response.ok() || wasmAudit.preflight.sha256 !== expectedWasmSha256) throw Error('Served engine bytes do not match the frozen candidate WASM');
} catch (error) {
  wasmAudit.errors.push(error.message); await saveWasmAudit();
  await context.close(); await browser.close(); throw error;
}
await context.addInitScript(() => {
  performance.setResourceTimingBufferSize(5000);
  window.__quad = { captureSchemaVersion: 4, starts: [], ready: [], states: [], queries: {}, digitalBatches: [], digitalHistoryOmitted: 0, numericBatches: [], numericHistoryOmitted: 0, calls: [], commands: [], errors: [], messages: [], fileEvents: [], pickerEvents: [] };
  const bounded = (array, value, limit) => { array.push(value); if (array.length > limit) array.shift(); };
  for (const type of ['input', 'change', 'cancel']) document.addEventListener(type, event => {
    const target = event.target;
    if (target instanceof HTMLInputElement && target.type === 'file') bounded(window.__quad.fileEvents, { type, wallMs: Date.now(), accept: target.accept, files: [...(target.files ?? [])].map(file => ({ name: file.name, bytes: file.size })) }, 50);
  }, true);
  window.addEventListener('message', event => {
    if (event.data?.type?.startsWith('kernelcad.runtime.')) bounded(window.__quad.messages, { wallMs: Date.now(), origin: event.origin, data: event.data }, 200);
  });
  const NativeWorker = window.Worker;
  let workerSerial = 0;
  window.Worker = class extends NativeWorker {
    constructor(...args) {
      super(...args);
      this.auditId = ++workerSerial;
      this.auditQueries = new Map();
      this.auditWatchEpochs = new Map();
      this.addEventListener('message', event => {
        const outer = event.data;
        const data = outer?.t === 'lab' ? outer.msg : outer;
        const chip = outer?.t === 'lab' ? outer.chip : null;
        const wallMs = Date.now();
        if (data?.t === 'ready') bounded(window.__quad.ready, { wallMs, worker: this.auditId, chip }, 100);
        if (outer?.t === 'labSnapshot') {
          bounded(window.__quad.states, structuredClone({ wallMs, worker: this.auditId, states: outer.states.map(({ chip, state }) => ({ chip, cycles: state.cycles, actuatorStates: state.actuatorStates, uartOutput: state.uartOutput })) }), 400);
        } else if (data?.t === 'snapshot') {
          bounded(window.__quad.states, structuredClone({ wallMs, worker: this.auditId, states: [{ chip, cycles: data.state.cycles, actuatorStates: data.state.actuatorStates, uartOutput: data.state.uartOutput }] }), 400);
        }
        if (data?.t === 'queryResult' || data?.t === 'queryError') {
          const key = `${chip ?? ''}:${data.id}`;
          const request = this.auditQueries.get(key);
          this.auditQueries.delete(key);
          if (request) {
            const family = request.method === 'analogSeries' ? `${request.method}:${request.args?.[0] ?? 'all'}` : request.method;
            const observed = structuredClone({ wallMs, worker: this.auditId, chip, request, response: data });
            window.__quad.queries[`${this.auditId}:${chip ?? ''}:${family}`] = observed;
            if (['watchLogicSignals', 'readLogicEdges', 'readLogicStates'].includes(request.method)) {
              if (window.__quad.digitalBatches.length === 1000) window.__quad.digitalHistoryOmitted++;
              bounded(window.__quad.digitalBatches, observed, 1000);
            }
            if (request.method === 'liveNumericCapture') {
              // A passive recorder bound, independent of native retention.
              // Every retained batch includes its unmodified cursor/loss data.
              if (window.__quad.numericBatches.length === 2000) window.__quad.numericHistoryOmitted++;
              bounded(window.__quad.numericBatches, observed, 2000);
            }
          }
        }
        if (['initError', 'commandError', 'stepError', 'queryError'].includes(data?.t)) bounded(window.__quad.errors, { wallMs, worker: this.auditId, chip, data }, 100);
      });
    }
    postMessage(outer, ...rest) {
      const data = outer?.t === 'lab' ? outer.msg : outer;
      const chip = outer?.t === 'lab' ? outer.chip : null;
      const wallMs = Date.now();
      if (data?.t === 'init') {
        const start = {
          wallMs, worker: this.auditId, chip,
          config: {
            mode: data.payload?.mode,
            wasmBinUrl: data.payload?.wasmBinUrl ?? null,
            systemYaml: typeof data.payload?.systemYaml === 'string' ? data.payload.systemYaml : null,
            chipYaml: typeof data.payload?.chipYaml === 'string' ? data.payload.chipYaml : null,
          },
          firmware: { bytes: data.payload?.firmware?.byteLength ?? null, sha256: null },
        };
        window.__quad.starts.push(start);
        if (data.payload?.firmware) crypto.subtle.digest('SHA-256', data.payload.firmware).then(hash => {
          start.firmware.sha256 = [...new Uint8Array(hash)].map(byte => byte.toString(16).padStart(2, '0')).join('');
        }).catch(error => bounded(window.__quad.errors, { wallMs: Date.now(), message: `Firmware hash: ${error}` }, 100));
      }
      if (data?.t === 'command') bounded(window.__quad.commands, structuredClone({ wallMs, worker: this.auditId, chip, method: data.method, args: data.args }), 200);
      if (data?.t === 'query') {
        const sourceKey = chip ?? '';
        if (data.method === 'watchLogicSignals') this.auditWatchEpochs.set(sourceKey, (this.auditWatchEpochs.get(sourceKey) ?? 0) + 1);
        this.auditQueries.set(`${sourceKey}:${data.id}`, structuredClone({ id: data.id, method: data.method, args: data.args, sentAtMs: wallMs, watchEpoch: this.auditWatchEpochs.get(sourceKey) ?? 0 }));
        if (['watchLogicSignals', 'engineClockHz'].includes(data.method)) bounded(window.__quad.calls, structuredClone({ wallMs, worker: this.auditId, chip, method: data.method, args: data.args }), 200);
      }
      return super.postMessage(outer, ...rest);
    }
  };
});
const publicResponse = await context.request.get(`https://api.labwired.com/v1/projects/${projectId}`);
const publicDocument = await publicResponse.json();
const publicDiagram = JSON.parse(publicDocument.project.diagram_json);
await fs.writeFile(`${dir}/public-project.json`, JSON.stringify(publicDocument, null, 2));
if (process.env.QUAD_EXPECTED_VERSION && publicDiagram.mechanical?.version !== Number(process.env.QUAD_EXPECTED_VERSION)) {
  await browser.close(); throw Error('Public CAD version does not match the requested acceptance target');
}
const page = await context.newPage();
const pageErrors = [], consoleErrors = [], network = [], compiles = [], compileRequests = [], uploadedFirmware = [], marks = [], candidateSourceHashes = {};
if (process.env.QUAD_UPLOAD_GUARD_DIAGNOSTIC === '1' || process.env.QUAD_UPLOAD_ALLOCATION_DIAGNOSTIC === '1') {
  const debuggerSession = await context.newCDPSession(page);
  const guardDiagnostics = [], scriptUrls = new Map();
  debuggerSession.on('Debugger.scriptParsed', event => scriptUrls.set(event.scriptId, event.url));
  await debuggerSession.send('Debugger.enable');
  if (process.env.QUAD_UPLOAD_GUARD_DIAGNOSTIC === '1') for (const lineNumber of [42, 56, 59]) await debuggerSession.send('Debugger.setBreakpointByUrl', { urlRegex: '/src/target-properties/targetProperties\\.ts(?:\\?|$)', lineNumber });
  if (process.env.QUAD_UPLOAD_ALLOCATION_DIAGNOSTIC === '1') {
    await debuggerSession.send('Debugger.setBreakpointByUrl', { urlRegex: '/src/hooks/useAppRuntimeEngine\\.ts(?:\\?|$)', lineNumber: 159 });
    await debuggerSession.send('Debugger.setBreakpointByUrl', { urlRegex: '/src/install-uploaded-firmware\\.ts(?:\\?|$)', lineNumber: 59 });
  }
  debuggerSession.on('Debugger.paused', async event => {
    try {
      const frame = event.callFrames[0];
      const url = scriptUrls.get(frame.location.scriptId) ?? frame.url;
      const expression = url.includes('useAppRuntimeEngine')
        ? '({multiChip,mcuPartId:config.mcuPartId??null,configKeys:Object.keys(config),firmwareBytes:config.firmware?.byteLength??null})'
        : url.includes('install-uploaded-firmware')
          ? '({targetId,scopeCurrent:scopeGuard.isCurrent(),error:normalized})'
          : '({selectedOk:selected.ok,selectedTargetId:selected.targetId,capturedScopeId,currentScopeId:getCurrentScopeId(),capturedTarget:{id:capturedTarget.id,boardId:capturedTarget.boardId},currentTarget:(()=>{const t=getCurrentTarget(selected.targetId);return t?{id:t.id,boardId:t.boardId}:null})()})';
      const evaluated = await debuggerSession.send('Debugger.evaluateOnCallFrame', {
        callFrameId: frame.callFrameId, returnByValue: true, silent: true,
        expression,
      });
      guardDiagnostics.push({ wallMs: Date.now(), functionName: frame.functionName, url, lineNumber: frame.location.lineNumber, value: evaluated.result.value, exception: evaluated.exceptionDetails?.text });
      await fs.writeFile(`${dir}/upload-${process.env.QUAD_UPLOAD_ALLOCATION_DIAGNOSTIC === '1' ? 'allocation' : 'guard'}-diagnostic.json`, JSON.stringify(guardDiagnostics, null, 2));
    } finally { await debuggerSession.send('Debugger.resume').catch(() => {}); }
  });
}
page.on('pageerror', error => pageErrors.push(error.message));
page.on('console', message => { if (message.type() === 'error') consoleErrors.push(message.text().slice(0,1500)); });
page.on('request', request => {
  if (!request.url().includes('/v1/compile')) return;
  try {
    const body = request.postDataJSON();
    const channel = body.source?.match(/#define\s+CHANNEL_ID\s+(\d+)/)?.[1] ?? null;
    const sourceSha256 = typeof body.source === 'string' ? createHash('sha256').update(body.source).digest('hex') : null;
    if (process.env.QUAD_FIRMWARE_DIR && (!channel || candidateSourceHashes[`ctrl${channel}`] !== sourceSha256)) pageErrors.push(`Unexpected compile source for controller ${channel}`);
    compileRequests.push({ wallMs: Date.now(), board: body.board, language: body.language,
      channel, sourceSha256,
      projectId: body.project_id ?? null,
    });
  } catch (error) { pageErrors.push(`Could not record compile request: ${error.message}`); }
});
page.on('response', response => {
  if (/labwired\.com\/v1\/|kernelcad\.com\/api\//.test(response.url())) network.push({ url: response.url(), status: response.status() });
  if (response.url().includes('/v1/compile')) response.json().then(body => compiles.push({ wallMs: Date.now(), status: response.status(), success: body.success, errors: body.errors, elfSha256: body.elf ? createHash('sha256').update(Buffer.from(body.elf, 'base64')).digest('hex') : null })).catch(() => {});
});
const mark = async (name, extra = {}) => { const event = { name, wallMs: Date.now(), ...extra }; marks.push(event); console.log(JSON.stringify(event)); await fs.writeFile(`${dir}/events.json`, JSON.stringify(marks, null, 2)); };
const receipt = async name => {
  const data = await page.evaluate(() => {
    // Passive DOM receipt in the same evaluation as unmodified native audit data.
    // The paused-clock receipt gives a stable native horizon for label comparison.
    const byTestId = id => document.querySelector(`[data-testid="${id}"]`);
    const attributes = element => element ? Object.fromEntries([...element.attributes].map(attribute => [attribute.name, attribute.value])) : null;
    const uiSnapshot = {
      receiptWallMs: Date.now(),
      latestControllerCycles: Object.fromEntries(window.__quad.states.flatMap(entry => entry.states.map(state => [state.chip, state.cycles]))),
      logicChannels: ['CH0', 'CH1', 'CH2', 'CH3'].map(channel => ({
        channel,
        ownerSignal: byTestId(`logic-probe-select-${channel}`)?.value ?? null,
        badgeText: byTestId(`logic-channel-value-${channel}`)?.textContent ?? null,
        summaryLevelText: byTestId(`logic-channel-summary-level-${channel}`)?.textContent ?? null,
        summaryText: byTestId(`logic-channel-summary-${channel}`)?.textContent ?? null,
        channelText: byTestId(`logic-channel-${channel}`)?.textContent ?? null,
        waveformLabelText: byTestId(`logic-waveform-label-${channel}`)?.textContent ?? null,
        waveformAttributes: attributes(byTestId(`logic-waveform-${channel}`)),
        highZRegions: [...document.querySelectorAll(`[data-testid="logic-highz-${channel}"]`)].map(attributes),
      })),
      logicSummaryRootHtml: byTestId('logic-raw-waveform-root')?.outerHTML ?? null,
      logicSvgHtml: byTestId('logic-raw-waveform')?.outerHTML ?? null,
      scopeHtml: byTestId('oscilloscope-panel')?.outerHTML ?? null,
    };
    return { audit: window.__quad, uiSnapshot, body: document.body.innerText,
      selects: [...document.querySelectorAll('select')].map(element => ({ label: element.getAttribute('aria-label'), value: element.value,
        options: [...element.options].map(option => ({ value: option.value, label: option.label })) })) };
  });
  const preparedConfigs = [];
  for (const [index, start] of data.audit.starts.entries()) {
    const configs = {};
    for (const key of ['systemYaml', 'chipYaml']) {
      const yaml = start.config?.[key];
      if (typeof yaml !== 'string') continue;
      const filename = `init-${index}-${key}.yaml`;
      await fs.writeFile(`${dir}/${filename}`, yaml);
      configs[key] = {
        file: filename,
        sha256: createHash('sha256').update(yaml).digest('hex'),
        clockFields: yaml.split('\n').map((line, index) => ({ line: index + 1, text: line })).filter(({ text }) => /^\s*(cpu_hz|simulation_clock_hz):/.test(text)),
      };
    }
    preparedConfigs.push({ chip: start.chip, worker: start.worker, mode: start.config?.mode, wasmBinUrl: start.config?.wasmBinUrl, firmware: start.firmware, configs });
  }
  await fs.writeFile(`${dir}/prepared-configs.json`, JSON.stringify(preparedConfigs, null, 2));
  await saveWasmAudit();
  await fs.writeFile(`${dir}/${name}.json`, JSON.stringify({ origin, url: page.url(), publicContentHash: publicDocument.project.content_hash, publicMechanical: publicDiagram.mechanical, pageErrors, consoleErrors, compiles, compileRequests, uploadedFirmware, ...data }, null, 2));
  await page.screenshot({ path: `${dir}/${name}.png` });
  return data;
};
const signalKey = (owner, kind, ...details) => JSON.stringify([owner, kind, ...details]);
const latestCycles = audit => Object.fromEntries(audit.states.flatMap(entry => entry.states.map(state => [state.chip, state.cycles])));
const observedCycles = () => page.evaluate(() => Object.fromEntries(window.__quad.states.flatMap(entry => entry.states.map(state => [state.chip, state.cycles]))));
const scopeSignals = { CH1: signalKey('ctrl1', 'analog', 'motor.rotor1.current_a'), CH2: signalKey('ctrl1', 'analog', 'motor.rotor1.speed_rpm'), CH3: signalKey('ctrl1', 'digital', 'gpio', 'gpioa', 8), CH4: signalKey('ctrl1', 'digital', 'gpio', 'gpioc', 0) };
const logicSignals = { CH0: signalKey('ctrl1', 'digital', 'gpio', 'gpioa', 8), CH1: signalKey('ctrl1', 'digital', 'gpio', 'gpiob', 13), CH2: signalKey('ctrl1', 'digital', 'gpio', 'gpiob', 7), CH3: signalKey('ctrl1', 'digital', 'gpio', 'gpiob', 0) };

// A fresh native observation after the selected source/coast boundary. A
// cumulative eviction count is not loss for an up-to-date reader. A bounded
// newest suffix can omit older requested points; keep that gap explicit and
// establish coverage only from actual returned points and per-signal horizons.
function observedLiveNumeric({ chip, names, since, cycle }) {
  const all = Object.values(window.__quad.queries);
  if (!Number.isSafeInteger(cycle) || cycle < 0) return null;
  for (const query of [...window.__quad.numericBatches].reverse()) {
    if (query.chip !== chip || query.request.method !== 'liveNumericCapture'
      || query.request.args?.[1] !== 2048
      || query.request.sentAtMs < since || query.wallMs < query.request.sentAtMs) continue;
    const clock = all.find(clockQuery => clockQuery.chip === chip && clockQuery.worker === query.worker
      && clockQuery.request.method === 'engineClockHz')?.response.value;
    if (clock !== 4000000) continue;
    const boundaryNs = cycle * 1e9 / clock;
    const batch = query.response.value;
    if (!batch || query.response.t !== 'queryResult' || typeof batch.epoch !== 'string' || !batch.epoch
      || batch.resetRequired !== false || batch.readerMissed !== 0
      || !Array.isArray(batch.channels) || !Array.isArray(batch.points) || !batch.points.length) continue;
    if (!Number.isSafeInteger(batch.nextCursor) || !Number.isSafeInteger(batch.oldestCursor)
      || !Number.isSafeInteger(batch.omitted) || batch.omitted < 0
      || !Number.isSafeInteger(query.request.args[0]) || query.request.args[0] < batch.oldestCursor
      || batch.points[0].seq !== query.request.args[0] + batch.omitted
      || batch.points[batch.points.length - 1].seq !== batch.nextCursor - 1
      || batch.points.some((point, index) => !Number.isSafeInteger(point.seq)
        || (index > 0 && point.seq !== batch.points[index - 1].seq + 1))) continue;
    const channels = names.map(name => {
      const index = batch.channels.findIndex(channel => channel.name === name);
      const channel = batch.channels[index];
      if (!channel || channel.valid !== true || channel.invalidReason !== null
        || !Number.isSafeInteger(channel.knownFromNs) || !Number.isSafeInteger(channel.knownUntilNs)
        || channel.knownFromNs > channel.knownUntilNs || channel.knownUntilNs <= boundaryNs) return null;
      const points = batch.points.filter(point => point.channel === index && Number.isSafeInteger(point.timeNs)
        && point.timeNs > boundaryNs && point.timeNs >= channel.knownFromNs
        && point.timeNs <= channel.knownUntilNs && Number.isFinite(point.value));
      if (!points.length) return null;
      return { ...channel, observedFromNs: points[0].timeNs, pointCount: points.length,
        firstPoint: points[0], lastPoint: points[points.length - 1] };
    });
    if (channels.some(channel => channel === null)) continue;
    return { chip, worker: query.worker, clockHz: clock, since, cycle, boundaryNs,
      request: query.request, responseWallMs: query.wallMs, epoch: batch.epoch,
      oldestCursor: batch.oldestCursor, nextCursor: batch.nextCursor,
      readerMissed: batch.readerMissed, evicted: batch.evicted, omitted: batch.omitted,
      resetRequired: batch.resetRequired, channels };
  }
  return null;
}

async function waitLiveNumeric(chip, names, since, cycle) {
  const observed = await page.waitForFunction(observedLiveNumeric, { chip, names, since, cycle }, { timeout: 15000 });
  return observed.jsonValue();
}

// Read-only observation of the native query replies. Each edge retains its
// owning worker, chip, native cycle and watch epoch; no waveform is inferred.
function observedNativePins({ chip, pins, since }) {
  const batches = window.__quad.digitalBatches;
  const watches = new Map();
  const observed = pins.map(pin => ({ ...pin, rising: 0, falling: 0, stateCounts: {}, samples: [], stateSamples: [], epochs: [] }));
  const epochKey = batch => `${batch.worker}:${batch.chip}:${batch.request.watchEpoch}`;
  for (const batch of batches) {
    if (batch.chip !== chip) continue;
    if (batch.request.method === 'watchLogicSignals' && Array.isArray(batch.response.value)) {
      watches.set(epochKey(batch), batch.response.value);
    }
    if (!['readLogicEdges', 'readLogicStates'].includes(batch.request.method) || batch.wallMs < since || batch.request.sentAtMs < since) continue;
    const watch = watches.get(epochKey(batch));
    if (!watch) continue;
    for (const pin of observed) {
      const native = watch.find(ref => ref.kind === 'gpio' && ref.peripheral === pin.peripheral && ref.pin === pin.pin);
      if (!native) continue;
      const edges = (batch.response.value?.edges ?? []).filter(edge => edge.ch === native.ch);
      for (const edge of edges) {
        if (batch.request.method === 'readLogicEdges') {
          if (edge.value) pin.rising++; else pin.falling++;
          if (pin.samples.length < 32) pin.samples.push({ worker: batch.worker, watchEpoch: batch.request.watchEpoch, ...edge });
        } else {
          pin.stateCounts[edge.state] = (pin.stateCounts[edge.state] ?? 0) + 1;
          if (pin.stateSamples.length < 32) pin.stateSamples.push({ worker: batch.worker, watchEpoch: batch.request.watchEpoch, ...edge });
        }
      }
      if (edges.length && !pin.epochs.includes(batch.request.watchEpoch)) pin.epochs.push(batch.request.watchEpoch);
    }
  }
  const clock = Object.values(window.__quad.queries).find(query => query.chip === chip && query.request.method === 'engineClockHz')?.response.value;
  if (clock !== 4000000 || observed.some(pin => pin.expectedStates
    ? pin.expectedStates.some(state => !pin.stateCounts[state])
    : !pin.rising || !pin.falling)) return null;
  return { chip, clockHz: clock, since, pins: observed };
}

async function waitNativePins(chip, pins, since) {
  const observed = await page.waitForFunction(observedNativePins, { chip, pins, since }, { timeout: 30000 });
  return observed.jsonValue();
}

async function arrangeTool(panel, geometry) {
  const dialog = panel.locator('xpath=ancestor::*[@role="dialog"][1]');
  const header = dialog.locator(':scope > div').first();
  const bar = await header.boundingBox();
  const start = await dialog.boundingBox();
  if (!bar || !start) throw Error('Instrument window has no visible drag region');
  const from = { x: bar.x + Math.min(90, bar.width / 3), y: bar.y + bar.height / 2 };
  await page.mouse.move(from.x, from.y); await page.mouse.down();
  await page.mouse.move(from.x + geometry.x - start.x, from.y + geometry.y - start.y, { steps: 10 });
  await page.mouse.up();
  const moved = await dialog.boundingBox();
  const grip = await dialog.getByLabel('Resize window', { exact: true }).boundingBox();
  if (!moved || !grip) throw Error('Instrument window has no visible resize handle');
  const handle = { x: grip.x + grip.width / 2, y: grip.y + grip.height / 2 };
  await page.mouse.move(handle.x, handle.y); await page.mouse.down();
  await page.mouse.move(handle.x + geometry.width - moved.width, handle.y + geometry.height - moved.height, { steps: 10 });
  await page.mouse.up();
  return dialog.boundingBox();
}

try {
  await page.goto(`${origin}/p/${projectId}/edit?view=pcb`, { waitUntil: 'domcontentloaded', timeout: 60000 });
  await page.getByTestId('hardware-view-circuit').waitFor({ state: 'visible', timeout: 60000 });
  const decline = page.getByRole('button', { name: 'Decline', exact: true }); if (await decline.count()) await decline.click();
  await page.getByTestId('hardware-view-circuit').click();
  await page.locator('g[data-part-id="rotor1"]').waitFor({ state: 'visible', timeout: 30000 });
  await mark('actual-public-project-opened-on-branch', { publicVersion: publicDiagram.mechanical?.version });
  if (process.env.QUAD_PICKER_DIAGNOSTIC === '1') await page.evaluate(async () => {
    const url = performance.getEntriesByType('resource').map(entry => entry.name).find(name => /\/src\/target-properties\/targetProperties\.ts(?:\?|$)/.test(name));
    if (!url) throw Error('The loaded firmware picker module was not observed');
    const { TargetFirmwarePicker } = await import(url);
    const ids = new WeakMap(); let nextId = 1;
    const inputState = input => {
      if (!input) return null;
      if (!ids.has(input)) ids.set(input, nextId++);
      return { id: ids.get(input), isConnected: input.isConnected, value: input.value, files: [...(input.files ?? [])].map(file => ({ name: file.name, bytes: file.size })) };
    };
    const record = event => window.__quad.pickerEvents.push({ wallMs: Date.now(), ...event });
    for (const name of ['request', 'select', 'cancel']) {
      const original = TargetFirmwarePicker.prototype[name];
      TargetFirmwarePicker.prototype[name] = function(...args) {
        record({ method: name, phase: 'before', input: inputState(args[0]), targetId: name === 'request' ? args[1] : this.pending?.targetId, pendingInput: inputState(this.pending?.input) });
        const result = original.apply(this, args);
        record({ method: name, phase: 'after', input: inputState(args[0]), pendingTargetId: this.pending?.targetId, pendingInput: inputState(this.pending?.input) });
        if (name === 'request') result.then(value => record({ method: name, phase: 'resolved', result: { ok: value.ok, targetId: value.targetId, error: value.error, file: value.file ? { name: value.file.name, bytes: value.file.size } : undefined } }), error => record({ method: name, phase: 'rejected', error: String(error) }));
        return result;
      };
    }
    record({ phase: 'installed', moduleUrl: url });
  });
  if (process.env.QUAD_FIRMWARE_DIR) {
    for (const chip of ['ctrl1', 'ctrl2', 'ctrl3', 'ctrl4']) {
      const source = await fs.readFile(`${process.env.QUAD_FIRMWARE_DIR}/${chip}.c`, 'utf8');
      candidateSourceHashes[chip] = createHash('sha256').update(source).digest('hex');
      const part = page.locator(`g[data-part-id="${chip}"]`);
      await part.focus(); await page.keyboard.press('Enter');
      const inspector = page.locator('[role="dialog"][aria-label="Inspector window"]:visible').last();
      await inspector.getByRole('tab', { name: 'Source', exact: true }).click();
      const editor = inspector.locator('.monaco-editor');
      await editor.waitFor({ state: 'visible', timeout: 30000 });
      const modelContents = await page.evaluate(async ({ canonicalSource, channel }) => {
        const moduleUrl = performance.getEntriesByType('resource').map(entry => entry.name).find(name => /\/monaco-editor\.js(?:\?|$)/.test(name));
        if (!moduleUrl) throw Error('The actual loaded Monaco module was not found');
        const monaco = await import(moduleUrl);
        const visible = monaco.editor.getEditors().filter(candidate => {
          const node = candidate.getDomNode();
          const dialog = node?.closest('[role="dialog"][aria-label="Inspector window"]');
          const bounds = node?.getBoundingClientRect();
          return dialog && bounds?.width > 0 && bounds?.height > 0 && getComputedStyle(dialog).visibility !== 'hidden';
        });
        if (visible.length !== 1) throw Error(`Expected one visible inspector editor; found ${visible.length}`);
        visible[0].focus();
        const model = visible[0].getModel();
        if (!model) throw Error('The active source editor has no model');
        const before = model.getValue();
        if (before.match(/^#define\s+CHANNEL_ID\s+(\d+)/)?.[1] !== channel) throw Error(`The inspector source does not belong to controller ${channel}`);
        if (before !== canonicalSource) {
          model.setValue(canonicalSource);
          model.setEOL(canonicalSource.includes('\r\n') ? monaco.editor.EndOfLineSequence.CRLF : monaco.editor.EndOfLineSequence.LF);
        }
        return { before, after: model.getValue() };
      }, { canonicalSource: source, channel: chip.slice(4) });
      await fs.writeFile(`${dir}/editor-${chip}-before.c`, modelContents.before);
      await fs.writeFile(`${dir}/editor-${chip}-after.c`, modelContents.after);
      if (modelContents.after !== source) throw Error(`The actual ${chip} editor model does not match its candidate file`);
      await page.waitForTimeout(100);
      await mark('candidate-source-entered', { chip, sourceSha256: candidateSourceHashes[chip] });
      await inspector.getByRole('button', { name: 'Close window', exact: true }).click();
    }
    await receipt('firmware-edited');
  }
  if (process.env.QUAD_EDIT_ONLY !== '1') {
  if (process.env.QUAD_ELF_DIR) {
    const compileProvenance = JSON.parse(await fs.readFile(`${process.env.QUAD_ELF_DIR}/hosted-compile.json`, 'utf8'));
    const sourceProvenance = JSON.parse(await fs.readFile(`${process.env.QUAD_ELF_DIR}/candidate-manifest.json`, 'utf8'));
    await fs.copyFile(`${process.env.QUAD_ELF_DIR}/hosted-compile.json`, `${dir}/hosted-compile.json`);
    await fs.copyFile(`${process.env.QUAD_ELF_DIR}/candidate-manifest.json`, `${dir}/candidate-manifest.json`);
    for (const chip of ['ctrl1', 'ctrl2', 'ctrl3', 'ctrl4']) {
      const filename = `${process.env.QUAD_ELF_DIR}/${chip}.elf`;
      const bytes = await fs.readFile(filename);
      const sha256 = createHash('sha256').update(bytes).digest('hex');
      if (compileProvenance[chip]?.firmware_ref !== `sha256:${sha256}`) throw Error(`The ${chip} ELF does not match the authenticated compiler receipt`);
      const canonicalSource = await fs.readFile(`${process.env.QUAD_ELF_DIR}/${chip}.c`);
      const sourceSha256 = createHash('sha256').update(canonicalSource).digest('hex');
      if (sourceProvenance.sources[chip]?.candidate_sha256 !== sourceSha256) throw Error(`The ${chip} source no longer matches its compiler candidate`);
      const sourceArtifact = `executed-source-${chip}.c`;
      await fs.writeFile(`${dir}/${sourceArtifact}`, canonicalSource);
      candidateSourceHashes[chip] = sourceSha256;
      const part = page.locator(`g[data-part-id="${chip}"]`);
      await part.focus(); await page.keyboard.press('Enter');
      if (process.env.QUAD_FIRMWARE_DIR) {
      const sourceInspector = page.locator('[role="dialog"][aria-label="Inspector window"]:visible').last();
      await sourceInspector.getByRole('tab', { name: 'Source', exact: true }).click();
      await sourceInspector.locator('.monaco-editor').waitFor({ state: 'visible', timeout: 30000 });
      const persistedSource = await page.evaluate(async channel => {
        const moduleUrl = performance.getEntriesByType('resource').map(entry => entry.name).find(name => /\/monaco-editor\.js(?:\?|$)/.test(name));
        if (!moduleUrl) throw Error('The loaded Monaco module is unavailable');
        const monaco = await import(moduleUrl);
        const models = monaco.editor.getEditors().filter(candidate => {
          const node = candidate.getDomNode(); const dialog = node?.closest('[role="dialog"][aria-label="Inspector window"]');
          return dialog && getComputedStyle(dialog).visibility !== 'hidden' && candidate.getModel()?.getValue().match(/^#define\s+CHANNEL_ID\s+(\d+)/)?.[1] === channel;
        });
        if (models.length !== 1) throw Error('The reopened target source is ambiguous');
        return models[0].getModel().getValue();
      }, chip.slice(4));
      if (createHash('sha256').update(persistedSource).digest('hex') !== candidateSourceHashes[chip]) throw Error(`The ${chip} source changed after its inspector reopened`);
      }
      const targetInspector = page.locator('[role="dialog"][aria-label="Inspector window"]:visible:has([data-tour-anchor="target.properties"])').last();
      await targetInspector.getByRole('tab', { name: 'Properties', exact: true }).click();
      await page.waitForTimeout(1000);
      await targetInspector.getByRole('button', { name: 'Close window', exact: true }).click();
      const upload = page.getByRole('button', { name: 'Upload firmware', exact: true });
      if (await upload.count() !== 1) throw Error(`Expected one selected-target upload control for ${chip}`);
      const uploadState = await upload.evaluate(element => {
        const bounds = element.getBoundingClientRect();
        return {
          title: element.getAttribute('title'), disabled: element.disabled,
          ariaDisabled: element.getAttribute('aria-disabled'),
          toolbar: element.closest('[role="toolbar"]')?.getAttribute('aria-label'),
          bounds: { x: bounds.x, y: bounds.y, width: bounds.width, height: bounds.height },
          centerElements: document.elementsFromPoint(bounds.x + bounds.width / 2, bounds.y + bounds.height / 2).slice(0, 5).map(node => ({ tag: node.tagName, role: node.getAttribute('role'), label: node.getAttribute('aria-label'), className: typeof node.className === 'string' ? node.className.slice(0, 180) : null })),
        };
      });
      const expectedTargetLabel = publicDiagram.parts.find(part => part.id === chip)?.attrs?.label;
      if (expectedTargetLabel && !uploadState.toolbar?.includes(expectedTargetLabel)) throw Error(`Upload owner ${uploadState.toolbar} does not match ${chip}: ${expectedTargetLabel}`);
      await mark('firmware-upload-actionability', { chip, ...uploadState });
      await receipt(`upload-ready-${chip}`);
      const [chooser] = await Promise.all([
        page.waitForEvent('filechooser', { timeout: 15000 }),
        upload.click({ timeout: 10000 }),
      ]);
      await chooser.setFiles(filename);
      await mark('firmware-file-selected', { chip, bytes: bytes.length, fileEvents: await page.evaluate(() => window.__quad.fileEvents) });
      await page.waitForFunction(({ chip, sha256 }) => window.__quad.starts.some(start => start.chip === chip && start.firmware.sha256 === sha256)
        && window.__quad.ready.some(ready => ready.chip === chip), { chip, sha256 }, { timeout: 30000 });
      const engineUrl = await page.evaluate(target => window.__quad.starts.find(start => start.chip === target)?.config.wasmBinUrl, chip);
      if (!engineUrl || new URL(engineUrl, origin).href !== wasmAudit.preflight.requestedUrl) throw Error(`The ${chip} worker requested a different engine URL from the verified preflight`);
      uploadedFirmware.push({ chip, sha256, bytes: bytes.length, sourceSha256: candidateSourceHashes[chip], sourceArtifact, sourceOrigin: 'authenticated compiler candidate files', editorSourceReplaced: !!process.env.QUAD_FIRMWARE_DIR, compiler: compileProvenance[chip] });
      await mark('authenticated-elf-uploaded-through-ui', { chip, sha256, bytes: bytes.length });
      await receipt(`uploaded-${chip}`);
    }
    await receipt('uploaded-paused');
  }
  const toolParts = {};
  for (const name of ['Oscilloscope', 'Logic Analyzer']) {
    const beforeIds = new Set(await page.locator('g[data-part-id]').evaluateAll(parts => parts.map(part => part.getAttribute('data-part-id'))));
    await page.getByRole('button', { name: 'Tools', exact: true }).click();
    await page.getByRole('menuitemcheckbox', { name: new RegExp(name) }).click();
    const toolPanel = page.getByTestId(name === 'Oscilloscope' ? 'oscilloscope-panel' : 'logic-probe-select-CH0');
    await toolPanel.waitFor({ state: 'visible', timeout: 30000 });
    const addedIds = (await page.locator('g[data-part-id]').evaluateAll(parts => parts.map(part => part.getAttribute('data-part-id')))).filter(id => !beforeIds.has(id));
    if (addedIds.length !== 1) throw Error(`Expected exactly one new ${name} part; found ${addedIds.length}`);
    toolParts[name] = addedIds[0];
    await toolPanel.locator('xpath=ancestor::*[@role="dialog"][1]').getByRole('button', { name: 'Close window', exact: true }).click();
  }
  await receipt('tools-added-after-upload');
  for (const name of ['Oscilloscope', 'Logic Analyzer']) {
    await page.locator(`g[data-part-id="${toolParts[name]}"]`).focus();
    await page.keyboard.press('Enter');
    const panel = page.getByTestId(name === 'Oscilloscope' ? 'oscilloscope-panel' : 'logic-probe-select-CH0');
    await panel.waitFor({ state: 'visible', timeout: 30000 });
    await page.screenshot({ path: `${dir}/layout-before-${name === 'Oscilloscope' ? 'scope' : 'logic'}.png` });
    const bounds = await arrangeTool(panel, { x: name === 'Oscilloscope' ? 20 : 810, y: 150, width: 770, height: 650 });
    await mark('instrument-window-arranged', { instrument: name, bounds });
  }
  const toolSetup = await receipt('tools-reopened');
  if (process.env.QUAD_ELF_DIR && (toolSetup.audit.starts.length !== uploadedFirmware.length || compiles.length !== 0)) throw Error('Adding or reopening observational tools changed the uploaded runtime initialization or compile count');
  await mark('passive-insertion-preserved-uploaded-runtime', { initCount: toolSetup.audit.starts.length, compileCount: compiles.length });
  const run = page.getByRole('button', { name: /^Run( system| lab)?$/ }).first();
  if (await run.count()) await run.click();
  if (process.env.QUAD_COMPILE_ONLY === '1') {
    const deadline = Date.now() + 60000;
    while (compiles.length < 4 && !compiles.some(result => result.success === false || result.status >= 400) && Date.now() < deadline) await page.waitForTimeout(250);
    await receipt('ordinary-compile-attempt');
    await mark('ordinary-compile-attempt-complete', { compileRequests, compiles });
    if (compiles.length !== 4 || compiles.some(result => result.success !== true)) throw Error('Candidate ordinary compilation did not succeed for all four controllers');
  } else {
  await page.waitForFunction(() => {
    const states = window.__quad?.states ?? [];
    const latest = new Map(), uart = new Map();
    for (const entry of states) for (const state of entry.states) {
      uart.set(state.chip, state.uartOutput ?? '');
      for (const motor of state.actuatorStates ?? []) latest.set(motor.id, motor);
    }
    return [1, 2, 3, 4].every(index => Math.abs(latest.get(`rotor${index}`)?.speed_rpm ?? 0) > 200
      && uart.get(`ctrl${index}`)?.includes(`ROTOR ${index} HALL LOCKED`));
  }, {}, { timeout: 120000 });
  await mark('four-firmware-motors-hall-locked');
  if (process.env.QUAD_INIT_ONLY === '1') {
    await receipt('initialized');
    await mark('prepared-runtime-configs-captured');
  } else {
  if (process.env.QUAD_PAUSED_SETUP === '1') {
    await page.getByRole('button', { name: /^Pause( lab| system)?$/ }).first().click();
    await mark('paused-for-instrument-selection');
  }
  const scope = page.getByTestId('oscilloscope-panel');
  for (const [channel, value] of Object.entries(scopeSignals)) {
    const select = scope.getByLabel(`${channel} signal`, { exact: true });
    await select.locator('option').filter({ hasText: channel === 'CH1' ? 'motor.rotor1.current_a' : channel === 'CH2' ? 'motor.rotor1.speed_rpm' : 'ctrl1' }).first().waitFor({ state: 'attached', timeout: 30000 });
    await select.selectOption(value);
  }
  for (const [channel, value] of Object.entries(logicSignals)) await page.getByTestId(`logic-probe-select-${channel}`).selectOption(value);
  if (process.env.QUAD_PAUSED_SETUP === '1') await page.getByRole('button', { name: /^Run( lab| system)?$/ }).first().click();
  const healthyCaptureSince = Date.now();
  await page.waitForTimeout(Number(process.env.QUAD_HEALTHY_MS ?? 2500));
  const healthyPins = await waitNativePins('ctrl1', [{ peripheral: 'gpioa', pin: 8 }, { peripheral: 'gpiob', pin: 13, expectedStates: ['1', 'z'] }, { peripheral: 'gpioc', pin: 0 }], healthyCaptureSince);
  await mark('mixed-scope-and-logic-armed', { nativePins: healthyPins, lowSideMeaning: 'PB13 is the N-only phase A commutation gate; this firmware does not enable dead-time insertion.' });
  const healthy = await receipt('mixed-healthy');
  if (process.env.QUAD_ELF_DIR && (healthy.audit.starts.length !== uploadedFirmware.length || compiles.length !== 0
    || healthy.audit.starts.some(start => !uploadedFirmware.some(upload => upload.chip === start.chip && upload.sha256 === start.firmware.sha256)))) throw Error('The running lab no longer uses exactly the four uploaded authenticated ELFs');
  const startCount = healthy.audit.starts.length, compileCount = compiles.length;
  const ownerSwitchCycles = await observedCycles();
  const ownerSwitchStartedMs = Date.now();
  await mark('scope-source-selection-start', { since: ownerSwitchStartedMs, sourceId: 'ctrl2', signal: 'motor.rotor2.current_a', controllerCycles: ownerSwitchCycles });
  await scope.getByLabel('CH2 signal', { exact: true }).selectOption(signalKey('ctrl2', 'analog', 'motor.rotor2.current_a'));
  await page.waitForTimeout(Number(process.env.QUAD_SWITCH_MS ?? 1800));
  const ownerNumeric = await waitLiveNumeric('ctrl2', ['motor.rotor2.current_a'], ownerSwitchStartedMs, ownerSwitchCycles.ctrl2);
  const switched = await receipt('owner-switched');
  if (switched.audit.starts.length !== startCount || compiles.length !== compileCount) throw Error('Changing source restarted or recompiled firmware');
  const beforeCycles = latestCycles(healthy.audit), afterCycles = latestCycles(switched.audit);
  if (Object.entries(beforeCycles).some(([chip, cycles]) => !(afterCycles[chip] > cycles))) throw Error('A controller clock stopped or reset during source selection');
  await mark('source-switch-preserved-firmware-runtime', { initCount: startCount, compileCount, beforeCycles, afterCycles, numericCoverage: ownerNumeric });
  await scope.getByLabel('CH2 signal', { exact: true }).selectOption(scopeSignals.CH2);
  await page.waitForTimeout(Number(process.env.QUAD_RETURN_MS ?? 1000));

  const logicOwnerSwitchCycles = await observedCycles();
  const logicOwnerSwitchMs = Date.now();
  await mark('logic-source-selection-start', { since: logicOwnerSwitchMs, sourceId: 'ctrl2', signal: 'gpioa:8', controllerCycles: logicOwnerSwitchCycles });
  await page.getByTestId('logic-probe-select-CH0').selectOption(signalKey('ctrl2', 'digital', 'gpio', 'gpioa', 8));
  const ctrl2Logic = await waitNativePins('ctrl2', [{ peripheral: 'gpioa', pin: 8 }], logicOwnerSwitchMs);
  const ctrl1ScopeDigital = await waitNativePins('ctrl1', [{ peripheral: 'gpioa', pin: 8 }, { peripheral: 'gpioc', pin: 0 }], logicOwnerSwitchMs);
  const concurrentScopeNumeric = await waitLiveNumeric('ctrl1', ['motor.rotor1.current_a'], logicOwnerSwitchMs, logicOwnerSwitchCycles.ctrl1);
  const logicSwitched = await receipt('logic-owner-switched');
  if (logicSwitched.audit.starts.length !== startCount || compiles.length !== compileCount) throw Error('Changing the logic analyzer owner restarted or recompiled firmware');
  const logicSwitchCycles = latestCycles(logicSwitched.audit);
  if (Object.entries(afterCycles).some(([chip, cycles]) => !(logicSwitchCycles[chip] > cycles))) throw Error('A controller clock stopped or reset during logic-analyzer source selection');
  await mark('logic-source-switch-preserved-runtime-and-scope', { initCount: startCount, compileCount, ctrl2Logic, ctrl1ScopeDigital, controllerCycles: logicSwitchCycles, numericCoverage: concurrentScopeNumeric });

  // The supported analyzer has four lanes. B and C are separate native
  // capture windows; these receipts do not imply six simultaneous gate lanes.
  for (const phase of [{ name: 'B', high: 9, low: 14 }, { name: 'C', high: 10, low: 15 }, { name: 'A', high: 8, low: 13 }]) {
    const since = Date.now();
    await page.getByTestId('logic-probe-select-CH0').selectOption(signalKey('ctrl1', 'digital', 'gpio', 'gpioa', phase.high));
    await page.getByTestId('logic-probe-select-CH1').selectOption(signalKey('ctrl1', 'digital', 'gpio', 'gpiob', phase.low));
    const nativePins = await waitNativePins('ctrl1', [{ peripheral: 'gpioa', pin: phase.high }, { peripheral: 'gpiob', pin: phase.low, expectedStates: ['1', 'z'] }], since);
    const captured = await receipt(`gate-phase-${phase.name.toLowerCase()}`);
    if (captured.audit.starts.length !== startCount || compiles.length !== compileCount) throw Error(`Selecting phase ${phase.name} gate observations changed firmware runtime`);
    await mark('native-phase-gates-captured', { phase: phase.name, separateCaptureWindow: true, nativePins, initCount: startCount, compileCount });
  }
  if (process.env.QUAD_PAUSED_CLOCKS === '1') {
    const pauseRequestedMs = Date.now();
    await page.getByRole('button', { name: /^Pause( lab| system)?$/ }).first().click();
    await mark('paused-clock-window-requested', { pauseRequestedMs });
    await page.waitForTimeout(900);
    const first = await receipt('paused-clock-first');
    const runVisible = await page.getByRole('button', { name: /^Run( lab| system)?$/ }).first().isVisible();
    await page.waitForTimeout(900);
    const second = await receipt('paused-clock-and-retention');
    const firstCycles = latestCycles(first.audit), secondCycles = latestCycles(second.audit);
    const owners = ['ctrl1', 'ctrl2', 'ctrl3', 'ctrl4'];
    if (!runVisible || owners.some(owner => !Number.isSafeInteger(firstCycles[owner])
      || firstCycles[owner] !== secondCycles[owner])) throw Error('The four controller clocks did not remain paused');
    // Normal catalog discovery continues every1500ms while paused. Its [0,1]
    // read is enough for native per-channel horizons, without injecting queries.
    const pausedDescriptors = owners.map(owner => {
      const query = [...second.audit.numericBatches].reverse().find(observed => observed.chip === owner
        && observed.request.method === 'liveNumericCapture' && observed.request.args?.[0] === 0
        && observed.request.args?.[1] === 1 && observed.request.sentAtMs >= pauseRequestedMs
        && observed.wallMs >= observed.request.sentAtMs && observed.response.t === 'queryResult'
        && ['current_a', 'speed_rpm'].every(signal => observed.response.value?.channels?.some(channel =>
          channel.name === `motor.rotor${owner.slice(4)}.${signal}` && channel.valid === true
          && channel.invalidReason === null && Number.isSafeInteger(channel.knownUntilNs)
          && channel.knownUntilNs >= 0 && channel.knownUntilNs <= secondCycles[owner] * 250)));
      if (!query) throw Error(`No fresh native current/speed horizon was observed while ${owner} was paused`);
      return { chip: owner, worker: query.worker, request: query.request, responseWallMs: query.wallMs,
        epoch: query.response.value.epoch, channels: query.response.value.channels };
    });
    await mark('paused-clock-window-observed', { pauseRequestedMs, runControlVisible: runVisible,
      firstCycles, secondCycles, pausedDescriptors });
    await page.getByRole('button', { name: /^Run( lab| system)?$/ }).first().click();
  }
  if (process.env.QUAD_PROBE_ONLY === '1') await mark('probe-complete');
  else {
    const fault = page.locator('g[data-part-id="fault1"]');
    await fault.focus(); await page.keyboard.down('Space'); await mark('fault1-pressed');
    await page.waitForTimeout(12000); await page.keyboard.up('Space');
    await page.waitForFunction(() => {
      const states = window.__quad?.states ?? []; const latest = new Map();
      for (const entry of states) for (const state of entry.states) for (const motor of state.actuatorStates ?? []) latest.set(motor.id, motor);
      const uart = new Map(); for (const entry of states) for (const state of entry.states) uart.set(state.chip, state.uartOutput ?? '');
      return Math.abs(latest.get('rotor1')?.speed_rpm ?? Infinity) < 1
        && latest.get('rotor1')?.control_state === 'off:external-enable'
        && uart.get('ctrl1')?.includes('FAULT DRIVER')
        && ['rotor2', 'rotor3', 'rotor4'].every(id => Math.abs(latest.get(id)?.speed_rpm ?? 0) > 200 && latest.get(id)?.control_state === 'inverter');
    }, {}, { timeout: 30000 });
    const coastCycles = await observedCycles();
    const coastSince = Date.now();
    await mark('coast-confirmed', { since: coastSince, controllerCycles: coastCycles });
    const coastNumeric = await waitLiveNumeric('ctrl1', ['motor.rotor1.speed_rpm', 'motor.rotor1.current_a'], coastSince, coastCycles.ctrl1);
    await receipt('mixed-fault'); await mark('causal-motor1-shutdown', { numericCoverage: coastNumeric });
    // Capture-only extension after every functional proof has completed.
    // Close observational windows and frame the canvas through ordinary UI.
    for (const selector of ['oscilloscope-panel', 'logic-probe-select-CH0']) {
      await page.getByTestId(selector).locator('xpath=ancestor::*[@role="dialog"][1]')
        .getByRole('button', { name: 'Close window', exact: true }).click();
    }
    for (const name of ['Collapse Architect agent', 'Close build kit']) {
      const control = page.getByRole('button', { name, exact: true });
      if (await control.count() && await control.first().isVisible()) await control.first().click();
    }
    await page.getByTestId('hardware-view-circuit').click();
    let framed = false;
    for (let attempt = 0; attempt < 13; attempt++) {
      const canvas = await page.locator('.editor-canvas-shell').boundingBox();
      if (!canvas) throw Error('Circuit canvas is not visible for the design shot');
      const assemblies = await Promise.all([1, 2, 3, 4].flatMap(index => [`ctrl${index}`, `rotor${index}`])
        .map(id => page.locator(`g[data-part-id="${id}"]`).boundingBox()));
      framed = assemblies.every(bounds => bounds && bounds.x >= canvas.x && bounds.y >= canvas.y
        && bounds.x + bounds.width <= canvas.x + canvas.width && bounds.y + bounds.height <= canvas.y + canvas.height);
      if (framed) break;
      // Wheel navigation only. No part positions, settings or simulation inputs change.
      await page.mouse.move(canvas.x + canvas.width / 2, canvas.y + canvas.height / 2);
      await page.mouse.wheel(0, 100);
      await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
    }
    if (!framed) throw Error('The four motor visuals could not be framed through canvas navigation');
    const shotSince = Date.now();
    await mark('circuit-motors-shot-start', { since: shotSince, proofAlreadyCompleted: true });
    await page.waitForTimeout(4000);
    const circuitShot = await receipt('circuit-motors-after-proof');
    if (circuitShot.audit.starts.length !== startCount || compiles.length !== compileCount) throw Error('Closing tools or changing the view restarted or recompiled firmware');
    const shotStates = circuitShot.audit.states.filter(entry => entry.wallMs >= shotSince).flatMap(entry => entry.states);
    const shotMotors = new Map();
    for (const state of shotStates) for (const motor of state.actuatorStates ?? []) {
      shotMotors.set(motor.id, motor);
      if (motor.id === 'rotor1' ? motor.control_state !== 'off:external-enable'
        : ['rotor2', 'rotor3', 'rotor4'].includes(motor.id) && motor.control_state !== 'inverter') throw Error('Motor control state changed during the circuit shot');
    }
    if (!(Math.abs(shotMotors.get('rotor1')?.speed_rpm ?? Infinity) < 1)
      || ['rotor2', 'rotor3', 'rotor4'].some(id => !(Math.abs(shotMotors.get(id)?.speed_rpm ?? 0) > 200))) throw Error('The final circuit shot did not preserve M1 off and the other three running');
    await mark('circuit-motors-shot-complete', { since: shotSince, durationMs: Date.now() - shotSince,
      initCount: startCount, compileCount, controllerCycles: latestCycles(circuitShot.audit) });
  }
  }
  }
  }
  await Promise.allSettled([...wasmResponseTasks]);
  if (wasmAudit.errors.length) throw Error(wasmAudit.errors.join('; '));
  if (pageErrors.length) throw Error(`Browser errors: ${pageErrors.join('; ')}`);
} catch (error) {
  pageErrors.push(error.message); process.exitCode = 1; await mark('failure', { message: error.message }); await receipt('failure').catch(() => {});
} finally {
  await Promise.allSettled([...wasmResponseTasks]);
  await saveWasmAudit();
  await fs.writeFile(`${dir}/result.json`, JSON.stringify({ captureSchemaVersion: 4, origin, projectId, publicContentHash: publicDocument.project.content_hash, publicMechanical: publicDiagram.mechanical, status: process.exitCode ? 'failed' : 'passed', marks, pageErrors, network, compiles, compileRequests, uploadedFirmware }, null, 2));
  await context.close(); await browser.close();
}
