#!/usr/bin/env python3
"""Additive audit of native live numeric capture receipts.

The frozen prefix-series auditor remains unchanged. This version reuses its
firmware, WASM, clock, native gate, and plant checks, and substitutes only the
numeric observation source with the explicit bounded live recorder contract.
No observation is generated, interpolated, retimed, or recovered from a plant
snapshot. Exit 0 = pass, 1 = observed failure, 2 = incomplete evidence.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

BASE_SHA256 = "e378a94f346b6fba7b8772fffb6530003868dbd1f2fdf82557140e54aae3de9a"
BASE_PATH = Path(__file__).with_name("audit-native-acceptance.py")
if hashlib.sha256(BASE_PATH.read_bytes()).hexdigest() != BASE_SHA256:
    raise RuntimeError("The independent base auditor is not the frozen e378 source")
SPEC = importlib.util.spec_from_file_location("frozen_prefix_auditor", BASE_PATH)
BASE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)


def uint(value):
    return isinstance(value, int) and not isinstance(value, bool) and 0 <= value <= 2**53 - 1


def live_queries(data):
    """Keep raw native query identity; latest-query copies do not add events."""
    rows = data.get("audit", {}).get("numericBatches", []) + BASE.queries(data)
    seen, result = set(), []
    for query in rows:
        request = query.get("request", {})
        if request.get("method") != "liveNumericCapture":
            continue
        key = (query.get("worker"), query.get("chip"), query.get("wallMs"),
               query.get("response", {}).get("id"), request.get("sentAtMs"))
        if key not in seen:
            seen.add(key)
            result.append(query)
    return sorted(result, key=lambda q: q.get("wallMs", -1))


class LiveCapture:
    """Validate the native response before considering any channel coverage."""
    def __init__(self, data, phase):
        self.rows, self.batches, self.errors = [], [], []
        self.recorder_omitted = data.get("audit", {}).get("numericHistoryOmitted")
        self.unsupported = 0
        seen_points = {}
        channel_times = defaultdict(dict)
        for query in live_queries(data):
            native = BASE.value(query)
            if native is None:
                if query.get("response", {}).get("t") not in (None, "queryResult"):
                    self.errors.append("live native query failed")
                else:
                    self.unsupported += 1
                continue
            try:
                self.consume(query, native, phase, seen_points, channel_times)
            except (KeyError, TypeError, ValueError, IndexError) as error:
                self.errors.append(str(error))
        for key, indexed in channel_times.items():
            times = [time for _, time in sorted(indexed.items())]
            if times != sorted(times):
                self.errors.append(f"native channel timestamps moved backward: {key}")

    def consume(self, query, native, phase, seen_points, channel_times):
        if not isinstance(native, dict):
            raise ValueError("live native result is not an object or unsupported null")
        sent, received = query.get("request", {}).get("sentAtMs"), query.get("wallMs")
        if not BASE.finite(sent) or not BASE.finite(received) or received < sent:
            raise ValueError("live request/reply observation times are missing or reversed")
        args = query.get("request", {}).get("args", [])
        if len(args) != 2 or not all(uint(a) for a in args):
            raise ValueError("live request needs non-negative integer cursor and maxPoints")
        cursor, limit = args
        epoch = native.get("epoch")
        if not isinstance(epoch, str) or not epoch:
            raise ValueError("live epoch must be a nonempty native string")
        counters = ("oldestCursor", "nextCursor", "readerMissed", "evicted", "omitted")
        if not all(uint(native.get(k)) for k in counters):
            raise ValueError("live cursor/retention counters are missing or invalid")
        oldest, end = native["oldestCursor"], native["nextCursor"]
        reset = native.get("resetRequired")
        if not isinstance(reset, bool) or oldest > end or reset != (cursor > end):
            raise ValueError("live reset or cursor bounds contradict the request")
        channels, points = native.get("channels"), native.get("points")
        if not isinstance(channels, list) or not isinstance(points, list):
            raise ValueError("live channels and points must be native arrays")
        available = max(0, end - max(oldest, cursor))
        count = 0 if reset else min(available, limit, 20_000)
        expected_omitted = 0 if reset else available - count
        if len(points) != count or native["omitted"] != expected_omitted:
            raise ValueError("live newest-suffix point count or omitted counter is inconsistent")
        if native["readerMissed"] != max(0, oldest - cursor):
            raise ValueError("live readerMissed does not match the requested cursor")
        names = [c.get("name") for c in channels]
        if any(not isinstance(n, str) or not n for n in names) or len(set(names)) != len(names):
            raise ValueError("live channel names are missing or duplicated")
        per_channel = defaultdict(list)
        for index, channel in enumerate(channels):
            if not isinstance(channel.get("unit"), str) or not isinstance(channel.get("valid"), bool):
                raise ValueError("live channel unit or validity is missing")
            start, stop = channel.get("knownFromNs"), channel.get("knownUntilNs")
            if any(v is not None and not uint(v) for v in (start, stop)):
                raise ValueError("live channel horizons are not non-negative native integer ns")
            if start is not None and (stop is None or start > stop):
                raise ValueError("live channel known interval is reversed or has no end")
            reason = channel.get("invalidReason")
            if reason is not None and not isinstance(reason, str):
                raise ValueError("live invalidReason is neither text nor null")
        for offset, point in enumerate(points):
            seq, ch, stamp = point.get("seq"), point.get("channel"), point.get("timeNs")
            if not uint(seq) or seq != end - count + offset or not uint(ch) or ch >= len(channels):
                raise ValueError("live point sequence or channel index is inconsistent")
            if not uint(stamp) or not BASE.finite(point.get("value")):
                raise ValueError("live point is not a finite native observation")
            channel = channels[ch]
            stop = channel.get("knownUntilNs")
            if stop is None or stamp > stop:
                raise ValueError("live point exceeds its own channel's valid observation horizon")
            stream = (query.get("worker"), query.get("chip"), epoch)
            identity = (*stream, seq)
            payload = (channel["name"], stamp, point["value"])
            if identity in seen_points and seen_points[identity] != payload:
                raise ValueError("one native sequence number contains conflicting observations")
            seen_points[identity] = payload
            channel_times[(*stream, channel["name"])][seq] = stamp
            per_channel[ch].append(point)
        batch = {"phase": phase, "worker": query.get("worker"), "chip": query.get("chip"),
                 "sentAtMs": query.get("request", {}).get("sentAtMs"), "wallMs": query.get("wallMs"),
                 "requestCursor": cursor, "requestLimit": limit, "epoch": epoch,
                 **{k: native[k] for k in counters}, "resetRequired": reset, "returned": len(points),
                 "coldReadMissingPrehistory": cursor == 0 and native["readerMissed"] > 0,
                 "forwardReaderLoss": cursor > 0 and native["readerMissed"] > 0}
        self.batches.append(batch)
        for index, channel in enumerate(channels):
            # A new valid interval may coexist with retained points from a prior
            # interval. They remain raw evidence, but cannot establish its value.
            start = channel.get("knownFromNs")
            current = [p for p in per_channel[index] if start is not None and p["timeNs"] >= start]
            self.rows.append({**batch, **channel, "numericEvidenceKind": "native_live_capture",
                              "returnedForChannel": len(current), "retainedHistoricalPointsInReply": len(per_channel[index]),
                              "firstPointTimeNs": current[0]["timeNs"] if current else None,
                              "lastPointTimeNs": current[-1]["timeNs"] if current else None,
                              "points": current})

    def summary(self):
        return {"nativeBatches": len(self.batches), "unsupportedReplies": self.unsupported,
                "errors": sorted(set(self.errors)), "recorderNumericHistoryOmitted": self.recorder_omitted,
                "forwardReaderLossBatches": [b for b in self.batches if b["forwardReaderLoss"]],
                "coldReadMissingPrehistoryBatches": [b for b in self.batches if b["coldReadMissingPrehistory"]],
                "maxEvictedBySource": {chip: max(b["evicted"] for b in self.batches if b["chip"] == chip)
                                       for chip in {b["chip"] for b in self.batches}},
                "intentionalTrimBatches": sum(b["omitted"] > 0 for b in self.batches)}


def without_points(row):
    return {k: v for k, v in row.items() if k != "points"}


def covers(row, since, boundary):
    return (row.get("valid") is True and not row["resetRequired"] and row["readerMissed"] == 0 and row["requestLimit"] == 2048
            and BASE.finite(since) and BASE.finite(row["sentAtMs"]) and row["sentAtMs"] >= since
            and row["wallMs"] >= row["sentAtMs"] and BASE.finite(boundary)
            and BASE.finite(row["knownUntilNs"]) and row["knownUntilNs"] > boundary * BASE.NS_PER_CYCLE
            and BASE.finite(row["lastPointTimeNs"]) and row["lastPointTimeNs"] > boundary * BASE.NS_PER_CYCLE)


def coverage_evidence(row, boundary):
    observed = [p for p in row["points"] if p["timeNs"] > boundary * BASE.NS_PER_CYCLE]
    return {**without_points(row), "observedFromNsAfterBoundary": observed[0]["timeNs"] if observed else None,
            "observedUntilNsAfterBoundary": observed[-1]["timeNs"] if observed else None,
            "observationsAfterBoundary": len(observed)}


def digital_complete(summary):
    loss = summary.get("producerLoss", [])
    return bool(loss) and not summary.get("missing") and not summary.get("errors") and all(r.get("dropped") == 0 for r in loss)


class LiveAudit(BASE.Audit):
    def __init__(self, root, expected_wasm):
        super().__init__(root, expected_wasm)
        self.live = {name: LiveCapture(data, name) for name, data in self.phases.items() if data}

    def source_switches(self):
        start = len(self.checks)
        super().source_switches()
        for check in self.checks[start:]:
            if check["status"] == "fail":
                continue  # Selection or runtime-progress contradiction stays a failure.
            tool = check["check"].removesuffix("_owner_switch")
            phase = "owner-switched" if tool == "scope" else "logic-owner-switched"
            capture = self.live.get(phase)
            evidence = check["evidence"]
            if not capture or "cyclesAfter" not in evidence:
                continue
            owner, channel = ("ctrl2", "motor.rotor2.current_a") if tool == "scope" else ("ctrl1", "motor.rotor1.current_a")
            since = evidence.get("selectionStart", {}).get("since")
            boundary = evidence.get("coverageBoundaryCycle")
            rows = [r for r in capture.rows if r["chip"] == owner and r["name"] == channel and covers(r, since, boundary)]
            valid_digital = True
            if tool == "logic":
                counts = evidence.get("ctrl2PA8States", {})
                peers = evidence.get("concurrentScopeStates", {})
                valid_digital = ({"0", "1"} <= counts.keys() and len(peers) == 2
                                 and all({"0", "1"} <= c.keys() for c in peers.values())
                                 and digital_complete(evidence.get("digitalLoss", {}))
                                 and digital_complete(evidence.get("scopeDigitalLoss", {})))
            check["status"] = "pass" if rows and valid_digital and not capture.errors else "unknown"
            evidence["legacyNativeAnalog"] = evidence.pop("nativeAnalog", [])
            evidence["liveNativeAnalog"] = [coverage_evidence(r, boundary) for r in rows]
            evidence["liveCapture"] = capture.summary()
            check["note"] = "Fresh native live points and their own valid channel horizon must extend beyond the same selection cycle. Normal ring eviction does not authorize filling unavailable history. Firmware and digital checks are unchanged."

    def retention_and_pause(self):
        errors = [{"phase": phase, "errors": capture.errors} for phase, capture in self.live.items() if capture.errors]
        rows = [r for capture in self.live.values() for r in capture.rows]
        grid_errors = [without_points(r) for r in rows
                       if any(p["timeNs"] % BASE.NS_PER_CYCLE for p in r["points"])
                       or r["knownFromNs"] is not None and r["knownFromNs"] % BASE.NS_PER_CYCLE
                       or r["knownUntilNs"] is not None and r["knownUntilNs"] % BASE.NS_PER_CYCLE]
        self.check("native_live_numeric_records_and_retention", not errors and not grid_errors if rows else None,
                   {"errors": errors, "timeGridErrors": grid_errors,
                    "captures": {phase: capture.summary() for phase, capture in self.live.items()}},
                   "evicted counts old ring turnover, readerMissed counts unread records, omitted counts requested records excluded by the newest-suffix limit. Missing history has no reconstructed initial hold. Every point is a native accepted observation, including quiet observations.")
        first, second = self.phases.get("paused-clock-first"), self.phases.get("paused-clock-and-retention")
        mark = self.mark("paused-clock-window-observed")
        if not first or not second or not mark:
            self.check("paused_native_cycle_to_ns", None, {"missing": "two paused receipts plus observed-pause mark"})
            return
        a, b = BASE.cycles(first), BASE.cycles(second)
        stable = set(a) == set(b) == set(BASE.EXPECTED) and a == b and mark.get("runControlVisible") is True
        evidence, available, valid = [], True, stable
        capture = self.live["paused-clock-and-retention"]
        for chip in BASE.EXPECTED:
            candidates = [r for r in capture.rows if r["chip"] == chip and BASE.finite(r["sentAtMs"])
                          and r["sentAtMs"] >= mark.get("pauseRequestedMs", float("inf")) and not r["resetRequired"]]
            names = {r["name"] for r in candidates}
            required = {f"motor.rotor{chip[-1]}.current_a", f"motor.rotor{chip[-1]}.speed_rpm"}
            if not required <= names or chip not in b:
                available = False
                continue
            for name in sorted(required):
                row = max((r for r in candidates if r["name"] == name), key=lambda r: r["wallMs"])
                cpu_ns, horizon = b[chip] * BASE.NS_PER_CYCLE, row["knownUntilNs"]
                valid &= row["valid"] and BASE.finite(horizon) and 0 <= horizon <= cpu_ns and horizon % BASE.NS_PER_CYCLE == 0
                evidence.append({"chip": chip, "channel": name, "epoch": row["epoch"], "pausedCycles": b[chip],
                                 "cpuTimeNs": cpu_ns, "knownUntilNs": horizon,
                                 "sourceServiceLagNs": cpu_ns - horizon if BASE.finite(horizon) else None,
                                 "requestWallMs": row["sentAtMs"], "responseWallMs": row["wallMs"]})
        self.check("paused_native_cycle_to_ns", valid if available else False if not stable else None,
                   {"firstCycles": a, "secondCycles": b, "observedPause": mark, "perChannelPairs": evidence},
                   "Each valid channel uses its own native horizon. Actual service lag is reported without a guessed tolerance or timestamp snapping.")

    def fault(self):
        start = len(self.checks)
        super().fault()
        check = next((c for c in self.checks[start:] if c["check"] == "isolated_fault_and_coast"), None)
        if not check or check["status"] == "fail" or "plant" not in check["evidence"]:
            return  # All original observed plant/UART/latch failures remain failures.
        evidence = check["evidence"]
        capture = self.live.get("mixed-fault") or self.live.get("failure")
        if not capture:
            return
        since = evidence.get("coastConfirmed", {}).get("since")
        boundary = evidence.get("sourceCoverageBoundaryCycle")
        rows = [r for r in capture.rows if r["chip"] == "ctrl1" and covers(r, since, boundary)]
        required = {"motor.rotor1.current_a", "motor.rotor1.speed_rpm"}
        covered = required <= {r["name"] for r in rows}
        plant = evidence["plant"]
        physical = (plant["lastCycle"] > plant["firstCycle"]
                    and (plant["uniqueSpeeds"] > 1 or plant["uniquePositions"] > 1)
                    and evidence["latchedAfterRelease"] and evidence["coastConfirmedStateObserved"]
                    and all(r["continued"] for r in evidence["otherControllers"]))
        check["status"] = "pass" if covered and physical and not capture.errors else "unknown"
        evidence["legacyNativeAnalog"] = evidence.pop("nativeAnalog", [])
        evidence["liveNativeAnalog"] = [coverage_evidence(r, boundary) for r in rows if r["name"] in required]
        evidence["liveCapture"] = capture.summary()
        check["note"] = "Original all-observation latch, peer-state, UART, coast and native input/enable checks remain unchanged. Fresh live current and speed points, with their own valid horizons, must extend beyond the confirmed coast cycle. Ring history is never held across unavailable intervals."

    def run(self):
        report = super().run()
        report["schema"] = 2
        report["baseAuditorSha256"] = BASE_SHA256
        report["auditorSha256"] = BASE.sha(Path(__file__).read_bytes())
        report["numericContract"] = "live_numeric_capture/exclusive-sequence/per-channel-horizon/v1"
        historical = [r for phase, data in self.phases.items() if data for r in BASE.analog_rows(data, phase)]
        report["historicalSeriesCompatibilityEvidence"] = {
            "nativeObservations": [{k: v for k, v in r.items() if k != "points"} for r in historical],
            "note": "The historical run-long prefix recorder is preserved. Its exhaustion does not supply or extend live capture evidence; live acceptance requires the separate native endpoint."}
        return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("receipts", type=Path)
    parser.add_argument("--expected-wasm-sha256")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = LiveAudit(args.receipts.resolve(), args.expected_wasm_sha256).run()
    encoded = json.dumps(report, indent=2, allow_nan=False) + "\n"
    if args.output:
        args.output.write_text(encoded)
    print(json.dumps({"verdict": report["verdict"], "checks": [{"check": c["check"], "status": c["status"]} for c in report["checks"]], "output": str(args.output) if args.output else None}))
    if not args.output:
        print(encoded)
    return {"pass": 0, "fail": 1, "unknown": 2}[report["verdict"]]


if __name__ == "__main__":
    sys.exit(main())
