#!/usr/bin/env python3
"""Audit saved browser observations. Never create, resample, or repair a signal.

Usage: python3 audit-native-acceptance.py RECEIPTS --expected-wasm-sha256 SHA
         --output REPORT.json
Exit 0 = all required checks pass; 1 = observed failure; 2 = incomplete evidence.
Requires PyYAML, already used by the core validation tools. Inputs are read-only.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import sys
from urllib.parse import urljoin

import yaml

HZ = 4_000_000
NS_PER_CYCLE = 250
SOURCE_BYTES, ELF_BYTES = 6371, 83636
EXPECTED = {
    "ctrl1": ("36256da7e53f31dd6d50bb914a272a53e90ddbba566a30bf915fec47f5fc6150", "49297c048f21c43973aad9336d6a00eeea84c4e9643b772cf7e20baf95979620"),
    "ctrl2": ("09774243e8025a667d8d8ea0c6b9b81f88fe5c1c341d60a344c18400dbff8d6e", "f5bfb5b2b622269f09867548983cc4f3a6bdc65cadb1e82c2fe102f7f1eddddd"),
    "ctrl3": ("12bff38565d14c14052042fb7eb3995665ebed63edcd84d3909de64399b386c5", "cdf344fdf419bf446dd1c7d19798ca7b913d018079f447de1f96027edd118203"),
    "ctrl4": ("b97a0e22d27e7384176dafadc473688eafc2e142d985effa93bdf813807dcfdc", "e045f736ccad5b821b9c1cdb031ac5b3a7648ddbdd28446e32e863d8af909154"),
}
PHASES = ["tools-added-after-upload", "tools-reopened", "mixed-healthy", "owner-switched",
          "logic-owner-switched", "gate-phase-b", "gate-phase-c", "gate-phase-a",
          "paused-clock-first", "paused-clock-and-retention", "mixed-fault", "failure"]


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def value(query):
    return query.get("response", {}).get("value")


def queries(data, method=None, chip=None):
    return [q for q in data.get("audit", {}).get("queries", {}).values()
            if (method is None or q.get("request", {}).get("method") == method)
            and (chip is None or q.get("chip") == chip)]


def states(data):
    return [{**state, "wallMs": batch["wallMs"], "worker": batch.get("worker")}
            for batch in data.get("audit", {}).get("states", []) for state in batch.get("states", [])]


def latest(data):
    return {s["chip"]: s for s in sorted(states(data), key=lambda s: s["wallMs"])}


def cycles(data):
    return {chip: s["cycles"] for chip, s in latest(data).items()}


def motor(state):
    wanted = "rotor" + state.get("chip", "").removeprefix("ctrl")
    return next((m for m in state.get("actuatorStates", []) if m.get("id") == wanted), {})


def selected(data, label):
    for select in data.get("selects", []):
        if select.get("label") == label:
            try:
                return json.loads(select["value"])
            except (ValueError, TypeError):
                return select.get("value")
    return None


def fresh(query, since):
    sent = query.get("request", {}).get("sentAtMs")
    return finite(since) and finite(sent) and sent >= since and query.get("wallMs", -1) >= sent


def analog_rows(data, phase):
    rows = []
    for q in queries(data, "analogSeries"):
        native = value(q)
        if not isinstance(native, dict):
            continue
        for channel in native.get("channels", []):
            points = channel.get("points", [])
            dropped = channel.get("dropped")
            end = native.get("endTimeNs")
            tail = points[-1].get("timeNs") if points else None
            # Native SeriesRecorder drops NEW points after its fixed prefix fills.
            # A quiet hold is valid through endTimeNs while dropped == 0.
            known = end if dropped == 0 else tail if finite(dropped) and dropped > 0 else None
            rows.append({"phase": phase, "chip": q.get("chip"), "name": channel.get("name"),
                         "unit": channel.get("unit"), "sampling": channel.get("sampling"),
                         "requestLimit": (q.get("request", {}).get("args") or [None])[0],
                         "sentAtMs": q.get("request", {}).get("sentAtMs"), "wallMs": q.get("wallMs"),
                         "endTimeNs": end, "knownUntilNs": known, "lastPointTimeNs": tail,
                         "firstPointTimeNs": points[0].get("timeNs") if points else None,
                         "dropped": dropped, "omitted": channel.get("omitted"),
                         "retainedPointsDerived": len(points) + channel["omitted"] if isinstance(channel.get("omitted"), int) else None,
                         "returned": len(points), "points": points})
    return rows


class Digital:
    """Join native replies to their own worker/chip/watch epoch, never by label."""
    def __init__(self, data, chip, since):
        self.events = defaultdict(list)
        self.loss = {}
        self.missing, self.errors = [], []
        self.history_omitted = data.get("audit", {}).get("digitalHistoryOmitted")
        if not finite(since):
            self.missing.append("explicit capture-window start")
        batches = data.get("audit", {}).get("digitalBatches", []) + queries(data)
        watches = {}
        for q in batches:
            req = q.get("request", {})
            if q.get("chip") == chip and req.get("method") == "watchLogicSignals" and isinstance(value(q), list):
                epoch = (q.get("worker"), chip, req.get("watchEpoch"))
                if epoch[2] is not None:
                    watches[epoch] = {r.get("ch"): r for r in value(q)}
        seen, ranges = {}, defaultdict(list)
        for q in batches:
            req, native = q.get("request", {}), value(q)
            method = req.get("method")
            if q.get("chip") != chip or method not in ("readLogicEdges", "readLogicStates"):
                continue
            if finite(since) and not fresh(q, since):
                continue
            epoch = (q.get("worker"), chip, req.get("watchEpoch"))
            if epoch not in watches or not isinstance(native, dict):
                self.missing.append("native watch mapping or response for an observed batch")
                continue
            edges = native.get("edges", [])
            cursor, horizon, dropped = native.get("cursor"), native.get("nowCycle"), native.get("dropped")
            if not isinstance(cursor, int) or cursor < len(edges) or not finite(horizon):
                self.missing.append("native cursor or nowCycle")
                continue
            key = (*epoch, method)
            previous_loss = self.loss.get(key, 0)
            self.loss[key] = max(previous_loss, dropped) if isinstance(dropped, int) and previous_loss is not None else None
            if edges:
                ranges[key].append((cursor - len(edges), cursor))
            for index, edge in enumerate(edges):
                ref = watches[epoch].get(edge.get("ch"), {})
                if ref.get("kind") != "gpio":
                    continue
                # Core read_* returns the suffix ending at cursor. Its ordinal
                # retains distinct same-cycle transitions and deduplicates polls.
                event_id = (*key, cursor - len(edges) + index)
                payload = (ref.get("peripheral"), ref.get("pin"), edge.get("cycle"),
                           edge.get("state") if method == "readLogicStates" else edge.get("value"))
                if event_id in seen:
                    if seen[event_id] != payload:
                        self.errors.append("conflicting native event at one cursor")
                    continue
                seen[event_id] = payload
                if not isinstance(edge.get("cycle"), int) or not 0 <= edge["cycle"] <= horizon:
                    self.errors.append("edge outside its native cycle horizon")
                    continue
                self.events[(ref["peripheral"], ref["pin"], method)].append({
                    **edge, "epoch": epoch, "ordinal": event_id[-1], "wallMs": q.get("wallMs"),
                    "sentAtMs": req.get("sentAtMs"), "nowCycle": horizon})
        for events in self.events.values():
            events.sort(key=lambda e: (e["epoch"], e["cycle"], e["ordinal"]))
        for spans in ranges.values():
            end = None
            for start, stop in sorted(spans):
                if end is not None and start > end:
                    self.missing.append("recorder cursor gap inside the observed window")
                end = max(end or 0, stop)

    def pin(self, peripheral, pin, state=True):
        return self.events[(peripheral, pin, "readLogicStates" if state else "readLogicEdges")]

    def summary(self):
        return {"producerLoss": [{"worker": k[0], "chip": k[1], "watchEpoch": k[2],
                                  "method": k[3], "dropped": v} for k, v in self.loss.items()],
                "recorderDigitalHistoryOmitted": self.history_omitted,
                "missing": sorted(set(self.missing)), "errors": sorted(set(self.errors))}

    def complete(self):
        return bool(self.loss) and not self.missing and not self.errors and all(v == 0 for v in self.loss.values())


def carrier(events):
    """Measure interior PWM periods; preserve start/end partials and Z gaps."""
    groups = defaultdict(list)
    for edge in events:
        groups[tuple(edge["epoch"])].append(edge)
    histogram, interior, boundaries, gaps = Counter(), [], [], []
    burst_count = 0
    for epoch, ordered in groups.items():
        rises, burst, bursts = [], [], []
        for edge in ordered:
            if edge.get("state") == "1":
                rises.append(edge["cycle"])
            if edge.get("state") in ("0", "1"):
                if edge["state"] == "1":
                    burst.append(edge["cycle"])
            elif burst:
                bursts.append(burst)
                burst = []
        if burst:
            bursts.append(burst)
        histogram.update(b - a for a, b in zip(rises, rises[1:]))
        for run in bursts:
            burst_count += 1
            differences = [b - a for a, b in zip(run, run[1:])]
            # Firmware MMIO can truncate either boundary pulse. No interior
            # non-200 interval is discarded or silently classed as a gap.
            interior.extend(differences[1:-1])
            boundaries.extend(differences[:1] + differences[-1:] if len(differences) > 1 else differences)
        gaps.extend({"epoch": epoch, "fromCycle": a[-1], "toCycle": b[0], "cycles": b[0] - a[-1]}
                    for a, b in zip(bursts, bursts[1:]) if a and b)
    return {"burstCount": burst_count, "allRisingIntervalHistogramCycles": dict(sorted(histogram.items())),
            "interiorIntervals": len(interior), "interiorHistogramCycles": dict(Counter(interior)),
            "interiorViolations": [x for x in interior if x != 200],
            "boundaryIntervalHistogramCycles": dict(Counter(boundaries)), "commutationGaps": gaps,
            "periodCycles": 200, "periodNsAt4MHz": 50_000,
            "qualification": "Intervals stay within one watch epoch. Z/X breaks a binary burst; boundary pulses and gaps remain reported."}


def overlap(high, low):
    by_epoch = defaultdict(lambda: defaultdict(list))
    for side, events in enumerate((high, low)):
        for edge in events:
            by_epoch[tuple(edge["epoch"])][edge["cycle"]].append((side, edge))
    spans, known = [], 0
    for epoch, points in by_epoch.items():
        levels, previous = [None, None], None
        for cycle in sorted(points):
            if previous is not None and cycle > previous and all(x in ("0", "1", "z") for x in levels):
                known += cycle - previous
                if levels == ["1", "1"]:
                    spans.append({"epoch": epoch, "startCycle": previous, "endCycle": cycle})
            # Same-cycle transitions have zero duration; keep each lane's last
            # native event, not an arbitrary ordering between the two rings.
            for side, edge in sorted(points[cycle], key=lambda item: item[1]["ordinal"]):
                levels[side] = edge.get("state")
            previous = cycle
    return {"knownComparedCycles": known, "overlapSpans": spans}


class Audit:
    def __init__(self, root, expected_wasm):
        self.root, self.expected_wasm = root, expected_wasm
        self.hashes, self.checks = {}, []
        self.phases = {name: self.read(name + ".json") for name in PHASES}
        self.result = self.read("result.json") or {}
        self.marks = self.result.get("marks", [])

    def read(self, name):
        path = self.root / name
        if not path.is_file():
            return None
        raw = path.read_bytes()
        self.hashes[name] = sha(raw)
        return json.loads(raw)

    def check(self, name, verdict, evidence, note=None):
        self.checks.append({"check": name, "status": "unknown" if verdict is None else "pass" if verdict else "fail",
                            "evidence": evidence, **({"note": note} if note else {})})

    def mark(self, name, **attrs):
        return next((m for m in self.marks if m.get("name") == name and all(m.get(k) == v for k, v in attrs.items())), {})

    def identities(self):
        manifest, compiled = self.read("candidate-manifest.json"), self.read("hosted-compile.json")
        rows, all_ok, present = [], True, True
        for chip, (source_hash, _) in EXPECTED.items():
            path = self.root / f"executed-source-{chip}.c"
            if not path.is_file():
                present = False
                rows.append({"chip": chip, "missing": path.name})
                continue
            raw = path.read_bytes()
            self.hashes[path.name] = sha(raw)
            ok = len(raw) == SOURCE_BYTES and sha(raw) == source_hash
            all_ok &= ok
            rows.append({"chip": chip, "bytes": len(raw), "sha256": sha(raw), "matches": ok})
        self.check("four_exact_compile_source_witnesses", all_ok if present else False if not all_ok else None, rows,
                   "These canonical source bytes identify the authenticated compiler inputs. They do not claim the saved editor text was replaced or executed.")
        provenance = []
        for chip, (source_hash, elf_hash) in EXPECTED.items():
            source = (manifest or {}).get("sources", {}).get(chip, {})
            image = (compiled or {}).get(chip, {})
            matches = (source.get("candidate_sha256") == source_hash and source.get("bytes") == SOURCE_BYTES
                       and image.get("ok") is True and image.get("runnable") is True
                       and image.get("firmware_ref") == "sha256:" + elf_hash)
            provenance.append({"chip": chip, "sourceSha256": source.get("candidate_sha256"),
                               "sourceBytes": source.get("bytes"), "firmwareRef": image.get("firmware_ref"),
                               "compileSuccess": image.get("ok"), "runnable": image.get("runnable"),
                               "verificationStatus": image.get("verification_status"), "matches": matches})
        self.check("authenticated_source_and_elf_provenance", all(r["matches"] for r in provenance) if manifest and compiled else None,
                   provenance, "Compiler success is image provenance, not saved-project verification or physical execution proof.")
        rows, signatures = [], []
        for name, data in self.phases.items():
            if not data:
                continue
            starts, uploads = data.get("audit", {}).get("starts", []), data.get("uploadedFirmware", [])
            owners = [s.get("chip") for s in starts]
            ok = sorted(owners) == sorted(EXPECTED) and sorted(u.get("chip", "") for u in uploads) == sorted(EXPECTED)
            for start in starts:
                exp = EXPECTED.get(start.get("chip"))
                ok &= bool(exp and start.get("firmware", {}).get("sha256") == exp[1]
                           and start.get("firmware", {}).get("bytes") == ELF_BYTES)
            for upload in uploads:
                exp = EXPECTED.get(upload.get("chip"))
                ok &= bool(exp and (upload.get("sourceSha256"), upload.get("sha256")) == exp
                           and upload.get("bytes") == ELF_BYTES
                           and upload.get("compiler", {}).get("firmware_ref") == "sha256:" + exp[1]
                           and upload.get("sourceArtifact") == f"executed-source-{upload.get('chip')}.c"
                           and upload.get("editorSourceReplaced") is False)
            compiles, requests = data.get("compiles"), data.get("compileRequests")
            ok &= compiles == [] and requests == []
            signatures.append(sorted((s.get("chip"), s.get("worker"), s.get("wallMs"), s.get("firmware", {}).get("sha256")) for s in starts))
            rows.append({"phase": name, "initCount": len(starts), "owners": owners,
                         "editorSourceReplaced": {u.get("chip"): u.get("editorSourceReplaced") for u in uploads},
                         "compileResponses": len(compiles or []), "compileRequests": len(requests or []), "matches": ok})
        self.check("four_exact_runtime_images_no_restart_or_compile",
                   all(r["matches"] for r in rows) and all(s == signatures[0] for s in signatures) if rows else None, rows)
        wasm = self.read("wasm-provenance.json")
        if not wasm or not self.expected_wasm:
            self.check("actual_browser_wasm_identity", None, wasm, "Supply an independently frozen --expected-wasm-sha256; the receipt cannot authorize itself.")
        else:
            replies = wasm.get("browserResponses", [])
            starts = next((d["audit"]["starts"] for d in self.phases.values() if d), [])
            ok = wasm.get("expectedSha256") == self.expected_wasm and not wasm.get("errors")
            ok &= wasm.get("preflight", {}).get("sha256") == self.expected_wasm and bool(replies)
            ok &= all(r.get("sha256") == self.expected_wasm and 200 <= r.get("status", 0) < 300 for r in replies)
            ok &= all(any(r.get("url") == urljoin(self.result.get("origin", ""), s.get("config", {}).get("wasmBinUrl") or "") for r in replies) for s in starts)
            self.check("actual_browser_wasm_identity", ok, wasm)

    def clocks(self):
        prepared = self.read("prepared-configs.json")
        data = self.phases.get("mixed-healthy") or {}
        starts = {s.get("chip"): s for s in data.get("audit", {}).get("starts", [])}
        rows = []
        for item in prepared or []:
            row = {"chip": item.get("chip"), "matches": True}
            configs = {}
            for key in ("systemYaml", "chipYaml"):
                meta = item.get("configs", {}).get(key, {})
                path = self.root / meta.get("file", "MISSING")
                if not path.is_file():
                    row["matches"] = False
                    continue
                raw = path.read_bytes(); self.hashes[path.name] = sha(raw)
                row["matches"] &= sha(raw) == meta.get("sha256") and raw.decode() == starts.get(item.get("chip"), {}).get("config", {}).get(key)
                configs[key] = yaml.safe_load(raw)
            system, chip = configs.get("systemYaml", {}), configs.get("chipYaml", {})
            def timed(node):
                if isinstance(node, dict):
                    return [v for k, v in node.items() if k == "simulation_clock_hz"] + [x for v in node.values() for x in timed(v)]
                return [x for v in node for x in timed(v)] if isinstance(node, list) else []
            row.update(systemCpuHz=system.get("cpu_hz"), chipDefaultCpuHz=chip.get("cpu_hz"), motorClocksHz=timed(system))
            row["matches"] &= row["systemCpuHz"] == HZ and bool(row["motorClocksHz"]) and all(h == HZ for h in row["motorClocksHz"])
            rows.append(row)
        self.check("prepared_four_controller_clocks", len(rows) == 4 and {r["chip"] for r in rows} == set(EXPECTED) and all(r["matches"] for r in rows) if prepared else None, rows,
                   "The selected chip's default may be80MHz; the prepared runtime system and motor denominators must both be4MHz.")
        observed = sorted({(q.get("chip"), value(q)) for d in self.phases.values() if d for q in queries(d, "engineClockHz") if finite(value(q))})
        self.check("queried_effective_clock_for_instrument_owners", all(h == HZ for _, h in observed) and {"ctrl1", "ctrl2"} <= {c for c, _ in observed} if observed else None, observed)
        locks = {c: f"ROTOR {c[-1]} HALL LOCKED" in s.get("uartOutput", "") for c, s in latest(data).items() if c in EXPECTED}
        self.check("four_firmware_hall_lock_markers", all(locks.values()) and set(locks) == set(EXPECTED) if data else None, locks,
                   "This is the firmware predicate, not proof of closed-loop speed regulation or physical flight.")

    def gate_windows(self):
        for phase, high_pin, low_pin in [("a", 8, 13), ("b", 9, 14), ("c", 10, 15)]:
            data = self.phases.get("gate-phase-" + phase)
            mark = self.mark("native-phase-gates-captured", phase=phase.upper())
            since = mark.get("nativePins", {}).get("since")
            if not data:
                self.check("native_gate_pair_" + phase, None, {"missing": "gate-phase-" + phase + ".json"})
                continue
            capture = Digital(data, "ctrl1", since)
            high, low = capture.pin("gpioa", high_pin), capture.pin("gpiob", low_pin)
            counts = {"high": dict(Counter(e.get("state") for e in high)), "low": dict(Counter(e.get("state") for e in low))}
            carrier_report, overlap_report = carrier(high), overlap(high, low)
            selection_ok = selected(data, "CH0 probe source") == ["ctrl1", "digital", "gpio", "gpioa", high_pin] and selected(data, "CH1 probe source") == ["ctrl1", "digital", "gpio", "gpiob", low_pin]
            enough = {"0", "1"} <= counts["high"].keys() and {"1", "z"} <= counts["low"].keys() and carrier_report["interiorIntervals"] > 0 and overlap_report["knownComparedCycles"] > 0
            violations = bool(carrier_report["interiorViolations"] or overlap_report["overlapSpans"] or counts["high"].get("x") or counts["low"].get("x") or capture.errors or not selection_ok)
            verdict = False if violations else True if enough and capture.complete() and mark.get("separateCaptureWindow") is True else None
            self.check("native_gate_pair_" + phase, verdict, {"since": since, "pins": [f"PA{high_pin}", f"PB{low_pin}"], "stateCounts": counts,
                       "carrier": carrier_report, "overlap": overlap_report, "loss": capture.summary()},
                       "Separate phase window; N1/Z is read from native four-state events. No six-simultaneous-lane or dead-time claim for this firmware.")

    def source_switches(self):
        for tool, file, mark_name, before_file in [
            ("scope", "owner-switched", "scope-source-selection-start", "mixed-healthy"),
            ("logic", "logic-owner-switched", "logic-source-selection-start", "owner-switched")]:
            data, before = self.phases.get(file), self.phases.get(before_file)
            mark = self.mark(mark_name); since = mark.get("since")
            if not data or not before or not finite(since):
                self.check(tool + "_owner_switch", None, {"receipt": file, "selectionStart": mark})
                continue
            old, new = cycles(before), cycles(data)
            progressed = set(old) == set(new) == set(EXPECTED) and all(new[c] > old[c] for c in EXPECTED)
            if tool == "scope":
                channel, owner = "motor.rotor2.current_a", "ctrl2"
                selection_ok = selected(data, "CH2 signal") == [owner, "analog", channel]
                digital = None
            else:
                channel, owner = "motor.rotor1.current_a", "ctrl1"
                selection_ok = selected(data, "CH0 probe source") == ["ctrl2", "digital", "gpio", "gpioa", 8]
                digital = Digital(data, "ctrl2", since)
                scope_digital = Digital(data, "ctrl1", since)
            responses = [q for q in queries(data, "analogSeries", owner) if fresh(q, since) and q.get("request", {}).get("args") == [2048]
                         and any(c.get("name") == channel for c in (value(q) or {}).get("channels", []))]
            rows = [r for r in analog_rows(data, file) if r["name"] == channel and r["requestLimit"] == 2048 and finite(r["sentAtMs"]) and r["sentAtMs"] >= since and r["wallMs"] >= r["sentAtMs"]]
            boundary = mark.get("controllerCycles", mark.get("beforeCycles", {})).get(owner)
            if boundary is None:
                prior = [s for s in states(data) if s.get("chip") == owner and s["wallMs"] <= since]
                boundary = prior[-1]["cycles"] if prior else old.get(owner)
            coverage = any(r["dropped"] == 0 and r["returned"] > 0 and finite(r["knownUntilNs"]) and finite(boundary) and r["knownUntilNs"] > boundary * NS_PER_CYCLE for r in rows)
            observed = {"selectionStart": mark, "cyclesBefore": old, "cyclesAfter": new, "coverageBoundaryCycle": boundary,
                        "nativeAnalog": [{k: v for k, v in r.items() if k != "points"} for r in rows]}
            valid_digital = True
            if digital:
                counts = Counter(e.get("state") for e in digital.pin("gpioa", 8))
                scope_counts = {pin: dict(Counter(e.get("state") for e in scope_digital.pin(peripheral, pin))) for peripheral, pin in [("gpioa", 8), ("gpioc", 0)]}
                valid_digital = digital.complete() and scope_digital.complete() and {"0", "1"} <= counts.keys() and all({"0", "1"} <= x.keys() for x in scope_counts.values())
                observed.update(ctrl2PA8States=dict(counts), concurrentScopeStates=scope_counts, digitalLoss=digital.summary(), scopeDigitalLoss=scope_digital.summary())
            verdict = False if not selection_ok or not progressed else True if responses and coverage and valid_digital else None
            self.check(tool + "_owner_switch", verdict, observed,
                       "Fresh request and reply, selected native owner, and source coverage beyond the selection's observed native-cycle boundary are required; global init/compile identity is checked separately.")

    def retention_and_pause(self):
        rows = [r for name, data in self.phases.items() if data for r in analog_rows(data, name)]
        invalid = []
        for row in rows:
            points = row["points"]; times = [p.get("timeNs") for p in points]
            if not finite(row["endTimeNs"]) or not isinstance(row["dropped"], int) or not isinstance(row["omitted"], int):
                invalid.append({"phase": row["phase"], "channel": row["name"], "reason": "missing native retention metadata"}); continue
            if row["dropped"] < 0 or row["omitted"] < 0 or row["sampling"] != "hold" or not all(finite(t) and 0 <= t <= row["endTimeNs"] and t % NS_PER_CYCLE == 0 for t in times) or times != sorted(times) or not all(finite(p.get("value")) for p in points):
                invalid.append({"phase": row["phase"], "channel": row["name"], "reason": "invalid native change-point or retention data"})
        self.check("native_analog_retention_and_time_grid", not invalid and all(r["dropped"] == 0 for r in rows) if rows else None,
                   {"invalid": invalid, "observations": [{k: v for k, v in r.items() if k != "points"} for r in rows],
                    "recorderOmittedByPhase": {n: d.get("audit", {}).get("digitalHistoryOmitted") for n, d in self.phases.items() if d}},
                   "Producer dropped is not API omitted. After prefix exhaustion, aggregate endTimeNs does not extend a channel's retained tail. A quiet, drop-free hold remains valid through its producer horizon.")
        first, second = self.phases.get("paused-clock-first"), self.phases.get("paused-clock-and-retention")
        mark = self.mark("paused-clock-window-observed")
        if not first or not second or not mark:
            self.check("paused_native_cycle_to_ns", None, {"missing": "two paused receipts plus observed-pause mark"}); return
        a, b = cycles(first), cycles(second)
        stable = set(a) == set(b) == set(EXPECTED) and a == b and mark.get("runControlVisible") is True
        evidence, available, valid = [], True, stable
        for chip in EXPECTED:
            candidates = [r for r in analog_rows(second, "paused-clock-and-retention") if r["chip"] == chip and finite(r["sentAtMs"]) and r["sentAtMs"] >= mark.get("pauseRequestedMs", math.inf)]
            if not candidates or chip not in b:
                available = False; continue
            r = max(candidates, key=lambda x: x["wallMs"])
            cpu_ns = b[chip] * NS_PER_CYCLE
            valid &= finite(r["endTimeNs"]) and 0 <= r["endTimeNs"] <= cpu_ns and r["endTimeNs"] % NS_PER_CYCLE == 0
            evidence.append({"chip": chip, "pausedCycles": b[chip], "cpuTimeNs": cpu_ns, "nativeEndTimeNs": r["endTimeNs"],
                             "sourceServiceLagNs": cpu_ns - r["endTimeNs"], "requestWallMs": r["sentAtMs"], "responseWallMs": r["wallMs"]})
        self.check("paused_native_cycle_to_ns", valid if available else False if not stable else None,
                   {"firstCycles": a, "secondCycles": b, "observedPause": mark, "pairs": evidence},
                   "Lag is reported as observed. No axis relabeling, timestamp snapping, or invented maximum service latency.")

    def fault(self):
        data = self.phases.get("mixed-fault") or self.phases.get("failure")
        if not data:
            self.check("isolated_fault_and_coast", None, {"missing": "mixed-fault.json or failure.json"}); return
        commands = data.get("audit", {}).get("commands", [])
        presses = [c for c in commands if c.get("chip") == "ctrl1" and c.get("method") == "setBoardIoInput" and c.get("args") == ["fault1", True]]
        if not presses:
            self.check("isolated_fault_and_coast", None, {"missing": "actual fault1=true command"}); return
        down = presses[-1]["wallMs"]
        releases = [c for c in commands if c.get("chip") == "ctrl1" and c.get("method") == "setBoardIoInput" and c.get("args") == ["fault1", False] and c["wallMs"] > down]
        observed = sorted((s for s in states(data) if s["wallMs"] >= down), key=lambda s: (s["wallMs"], s["cycles"]))
        controller1 = [s for s in observed if s.get("chip") == "ctrl1"]
        off = [s for s in controller1 if motor(s).get("control_state") == "off:external-enable"]
        digital = Digital(data, "ctrl1", down)
        fault_high = [e for e in digital.pin("gpiob", 7) if e.get("state") == "1"]
        enable_low = [e for e in digital.pin("gpiob", 0) if e.get("state") == "0"]
        causal_pairs = [(a, b) for a in fault_high for b in enable_low if a["epoch"] == b["epoch"] and b["cycle"] >= a["cycle"]]
        self.check("native_fault_input_then_enable_low", True if causal_pairs and digital.complete() else None,
                   {"faultHighCycles": [e["cycle"] for e in fault_high], "enableLowCycles": [e["cycle"] for e in enable_low], "capture": digital.summary()})
        if not off:
            self.check("isolated_fault_and_coast", False, {"command": presses[-1], "offSnapshots": 0}); return
        first, last = off[0], controller1[-1]
        after_off = [s for s in controller1 if (s["wallMs"], s["cycles"]) >= (first["wallMs"], first["cycles"])]
        after_off_counts = Counter(motor(s).get("control_state") for s in after_off)
        stayed_off = all(motor(s).get("control_state") == "off:external-enable" for s in after_off)
        a, b = motor(first), motor(last)
        physical = {"offSnapshots": len(off), "firstCycle": first["cycles"], "lastCycle": last["cycles"],
                    "firstSpeedRpm": a.get("speed_rpm"), "lastSpeedRpm": b.get("speed_rpm"),
                    "uniqueSpeeds": len({motor(s).get("speed_rpm") for s in off}),
                    "uniquePositions": len({motor(s).get("position_rad") for s in off}),
                    "observationsAfterFirstOff": len(after_off), "controlStateCountsAfterFirstOff": dict(after_off_counts),
                    "latestControlState": b.get("control_state"), "remainedOffInEveryObservation": stayed_off}
        last_speed = b.get("speed_rpm")
        progressed = last["cycles"] > first["cycles"]
        changed = physical["uniqueSpeeds"] > 1 or physical["uniquePositions"] > 1
        uart_ok = all(text in last.get("uartOutput", "") for text in ["ROTOR 1 FAULT DRIVER", "ROTOR 1 INVERTER OFF"])
        latched = stayed_off and bool(releases) and last["wallMs"] >= releases[-1]["wallMs"]
        model_error = any(motor(s).get("control_state") == "fault:integration" or motor(s).get("faults") for s in observed)
        others = []
        for chip in ("ctrl2", "ctrl3", "ctrl4"):
            samples = [s for s in observed if s.get("chip") == chip]
            ok = len(samples) > 1 and samples[-1]["cycles"] > samples[0]["cycles"]
            state_counts = Counter(motor(s).get("control_state") for s in samples)
            stayed_inverter = bool(samples) and all(motor(s).get("control_state") == "inverter" for s in samples)
            if samples:
                initial, final = motor(samples[0]), motor(samples[-1])
                ok &= finite(final.get("speed_rpm")) and abs(final["speed_rpm"]) > 200 and stayed_inverter
                ok &= finite(initial.get("position_rad")) and finite(final.get("position_rad")) and final["position_rad"] != initial["position_rad"]
                ok &= "FAULT " not in samples[-1].get("uartOutput", "")
            others.append({"chip": chip, "samples": len(samples), "controlStateCounts": dict(state_counts),
                           "remainedInverterInEveryObservation": stayed_inverter, "continued": ok})
        wrong_fault = any(c.get("method") == "setBoardIoInput" and (c.get("args") or [None])[0] in ("fault2", "fault3", "fault4") and c.get("args", [None, None])[1] is True for c in commands if c.get("wallMs", 0) >= down)
        confirmed = self.mark("coast-confirmed")
        boundary, since = confirmed.get("controllerCycles", {}).get("ctrl1"), confirmed.get("since")
        confirmed_state = next((s for s in controller1 if s["cycles"] == boundary and finite(since) and s["wallMs"] <= since), None)
        confirmed_ok = (confirmed_state is not None and motor(confirmed_state).get("control_state") == "off:external-enable"
                        and finite(motor(confirmed_state).get("speed_rpm")) and abs(motor(confirmed_state)["speed_rpm"]) < 1)
        coverage = [r for r in analog_rows(data, "fault") if r["chip"] == "ctrl1" and r["requestLimit"] == 2048
                    and finite(since) and finite(r["sentAtMs"]) and r["sentAtMs"] >= since and r["wallMs"] >= r["sentAtMs"]]
        covered = all(any(r["name"] == name and r["dropped"] == 0 and r["returned"] > 0 and finite(r["knownUntilNs"]) and r["knownUntilNs"] > boundary * NS_PER_CYCLE for r in coverage)
                      for name in ("motor.rotor1.speed_rpm", "motor.rotor1.current_a")) if finite(boundary) else False
        failure = (model_error or wrong_fault or not uart_ok or not stayed_off or not finite(last_speed) or abs(last_speed) >= 1
                   or any(r["samples"] > 0 and not r["continued"] for r in others)
                   or confirmed_state is not None and not confirmed_ok)
        verdict = False if failure else True if progressed and changed and latched and confirmed_ok and covered and all(r["continued"] for r in others) else None
        self.check("isolated_fault_and_coast", verdict,
                   {"press": presses[-1], "release": releases[-1] if releases else None, "plant": physical,
                    "faultAndOffUART": uart_ok, "latchedAfterRelease": latched, "otherControllers": others,
                    "modelErrorObserved": model_error, "coastConfirmed": confirmed, "coastConfirmedStateObserved": confirmed_ok,
                    "sourceCoverageBoundaryCycle": boundary,
                    "nativeAnalog": [{k: v for k, v in r.items() if k != "points"} for r in coverage]},
                   "Every retained post-off state must stay off, and the other motors must stay in inverter state. Fresh drop-free analog horizons must extend beyond the confirmed coast cycle. Motor snapshots assess the plant only; coast need not be monotonic.")

    def run(self):
        for section in (self.identities, self.clocks, self.gate_windows, self.source_switches, self.retention_and_pause, self.fault):
            try:
                section()
            except (KeyError, TypeError, ValueError, AttributeError, IndexError) as error:
                self.check(section.__name__ + "_schema", None, {"error": str(error)}, "Malformed or unsupported evidence cannot pass.")
        failures = [n for n, d in self.phases.items() if d and (d.get("pageErrors") or any(e.get("data", {}).get("t") in ("initError", "stepError", "commandError") for e in d.get("audit", {}).get("errors", [])))]
        self.check("completed_browser_run", self.result.get("status") == "passed" and not failures if self.result else None,
                   {"driverStatus": self.result.get("status"), "phasesWithErrors": failures, "pageErrors": self.result.get("pageErrors")})
        overall = "fail" if any(c["status"] == "fail" for c in self.checks) else "unknown" if any(c["status"] == "unknown" for c in self.checks) else "pass"
        return {"schema": 1, "generatedAt": datetime.now(timezone.utc).isoformat(), "receiptDirectory": str(self.root),
                "auditorSha256": sha(Path(__file__).read_bytes()), "verdict": overall, "checks": self.checks,
                "inputSha256": self.hashes, "sourceReceipt": self.read("source-receipt.json"),
                "limits": ["Only saved observations are audited; missing evidence remains unknown.",
                           "Gate phase windows are separate, never represented as six simultaneous lanes.",
                           "No interpolation, replacement edges, timebase retiming, or synthetic analog samples.",
                           "This is a behavioral firmware bench audit, not native-board, flight, deployment, CAD-publication, or silicon validation."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("receipts", type=Path)
    parser.add_argument("--expected-wasm-sha256")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = Audit(args.receipts.resolve(), args.expected_wasm_sha256).run()
    encoded = json.dumps(report, indent=2, allow_nan=False) + "\n"
    if args.output:
        args.output.write_text(encoded)
    print(json.dumps({"verdict": report["verdict"], "checks": [{"check": c["check"], "status": c["status"]} for c in report["checks"]], "output": str(args.output) if args.output else None}))
    if not args.output:
        print(encoded)
    return {"pass": 0, "fail": 1, "unknown": 2}[report["verdict"]]


if __name__ == "__main__":
    sys.exit(main())
