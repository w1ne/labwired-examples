#ifndef AM32_TARGET_SENSORS_H
#define AM32_TARGET_SENSORS_H

#include <stdint.h>

/* A sensorless target must not turn an unsupported protection setting into
 * a successful arming condition, nor report floating pins as measurements. */
#define TARGET_SENSOR_ERROR_VOLTAGE 1U
#define TARGET_SENSOR_ERROR_CURRENT 2U

#if defined(TARGET_NO_EXTERNAL_SENSE) && (defined(USE_ADC_INPUT) || defined(USE_NTC) || defined(VOLTAGE_BASED_RAMP) || defined(FIXED_DUTY_MODE) || defined(FIXED_SPEED_MODE))
#error "This target has no external ADC channels for the requested mode"
#endif

static inline uint8_t target_sensor_errors(uint8_t voltage_cutoff, uint8_t current_limit)
{
#ifdef TARGET_NO_EXTERNAL_SENSE
    return (voltage_cutoff ? TARGET_SENSOR_ERROR_VOLTAGE : 0U)
        | (current_limit ? TARGET_SENSOR_ERROR_CURRENT : 0U);
#else
    (void)voltage_cutoff;
    (void)current_limit;
    return 0U;
#endif
}

#endif
