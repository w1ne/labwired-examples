# Native OPENESC30 complete-image source

The editable entry is am32-f421/Src/main.c. The build copies these expanded source trees into a new empty work directory and compiles them. It does not replace this entry with a hidden simulator fixture.

Use the exact xPack Arm GNU 10.3.1-2.3 compiler identified in sources/toolchain.json, Python 3.12+ and GNU make. From this extracted directory run:

    python3 build.py --source-dir . --toolchain-dir /absolute/toolchain --work-dir /absolute/new-empty-build

The command reproduces the native AM32 application, unchanged PB4 bootloader and complete ELF/BIN/HEX. The complete image uses the explicit EEPROM bytes in artifacts/. No binary application or bootloader is needed as a build input. All image identities are checked, and build-receipt.json records the actual expanded source files and output hashes.

Application source is pinned to OpenDrone-hw/AM32 upstream 5f8978eeb618c14bb396af7ac049d2a5e7b5a508 plus the included native target patch (source commit 19df1ecfef4982302cacdd35bb0d921ceac83217). Bootloader source is am32-firmware/AM32-bootloader a340e23f4fe270bf7a767156d3c24b10f22b521a. Original licenses and archives remain included.

This is the exact recorded engineering candidate. Source changes require a new artifact identity and runtime qualification before a saved Lab can use them. The source archive alone does not claim physical or five-node acceptance.
