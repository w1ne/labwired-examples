/*
 * Copyright (C) 2026 Andrii Shylenko
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * This file is part of iolinki.
 * See LICENSE for details.
 */

/* cfmakeraw() is a BSD/GNU extension; request it before any libc header so the
   declaration is visible under strict libc configurations (e.g. Zephyr native_sim). */
#ifndef _DEFAULT_SOURCE
#define _DEFAULT_SOURCE 1
#endif

/**
 * @file phy_virtual.c
 * @brief Virtual PHY backed by a POSIX serial port / pseudo-terminal.
 * @ingroup iolinki_phy_virtual
 *
 * Implements the PHY API over a host file descriptor (TTY or pipe) so the
 * device stack can be exercised via loopback or a virtual serial link during
 * development and testing.
 */

#include "iolinki/phy_virtual.h"
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>
#include <errno.h>
#include <string.h>

static int g_fd = -1;
static const char* g_port_path = NULL;

void iolink_phy_virtual_set_port(const char* port)
{
    g_port_path = port;
}

/** @brief Open and configure the backing serial port in raw, non-blocking mode. */
static int virtual_init(void* user)
{
    (void) user;

    if (g_port_path == NULL) {
        printf("[PHY-VIRTUAL] Error: Port not set\n");
        return -1;
    }

    g_fd = open(g_port_path, O_RDWR | O_NOCTTY | O_NONBLOCK);
    if (g_fd < 0) {
        printf("[PHY-VIRTUAL] Error opening %s: %s\n", g_port_path, strerror(errno));
        return -1;
    }

    /* Config for raw mode if it's a TTY */
    if (isatty(g_fd)) {
        struct termios tty;
        if (tcgetattr(g_fd, &tty) != 0) {
            printf("[PHY-VIRTUAL] Error from tcgetattr: %s\n", strerror(errno));
            return -1;
        }

        cfmakeraw(&tty);

        /* Set timeouts: No blocking */
        tty.c_cc[VMIN] = 0U;
        tty.c_cc[VTIME] = 0U;

        if (tcsetattr(g_fd, TCSANOW, &tty) != 0) {
            printf("[PHY-VIRTUAL] Error from tcsetattr: %s\n", strerror(errno));
            return -1;
        }
        printf("[PHY-VIRTUAL] Initialized TTY connection to %s (fd=%d)\n", g_port_path, g_fd);
    }
    else {
        printf("[PHY-VIRTUAL] Initialized non-TTY connection to %s (fd=%d)\n", g_port_path, g_fd);
    }
    return 0;
}

/** @brief Log the requested PHY mode (no electrical effect on the virtual link). */
static void virtual_set_mode(void* user, iolink_phy_mode_t mode)
{
    (void) user;
    printf("[PHY-VIRTUAL] Mode set to: %d\n", (int) mode);
}

/** @brief Log the requested baudrate (no effect on the virtual link). */
static void virtual_set_baudrate(void* user, iolink_baudrate_t baudrate)
{
    (void) user;
    printf("[PHY-VIRTUAL] Baudrate set to: %d\n", (int) baudrate);
}

/** @brief Write a buffer to the backing file descriptor. */
static int virtual_send(void* user, const uint8_t* data, size_t len)
{
    (void) user;

    if ((g_fd < 0) || (data == NULL)) {
        return -1;
    }
    if (len == 0U) {
        return 0;
    }
    return (int) write(g_fd, data, len);
}

/** @brief Non-blocking read of a single byte from the backing file descriptor. */
static int virtual_recv_byte(void* user, uint8_t* byte)
{
    (void) user;

    if ((g_fd < 0) || (byte == NULL)) {
        return 0;
    }

    ssize_t n = read(g_fd, byte, 1);
    return (n > 0) ? 1 : 0;
}

/** @brief Scan buffered input for a 0x55 wake-up marker byte. */
static int virtual_detect_wakeup(void* user)
{
    (void) user;

    if (g_fd < 0) {
        return 0;
    }

    /* Try to read bytes until we find 0x55 or run out of data */
    uint8_t b;
    while (read(g_fd, &b, 1) > 0) {
        if (b == 0x55) {
            return 1;
        }
    }
    return 0;
}

static const iolink_phy_api_t g_phy_virtual = {.init = virtual_init,
                                               .set_mode = virtual_set_mode,
                                               .set_baudrate = virtual_set_baudrate,
                                               .send = virtual_send,
                                               .recv_byte = virtual_recv_byte,
                                               .detect_wakeup = virtual_detect_wakeup};

const iolink_phy_api_t* iolink_phy_virtual_get(void)
{
    return &g_phy_virtual;
}
