LabWired imported native KiCad PCB DRC export
KiCad 10.0.8 design rule check: passed against generic selected clearances.
Vendor footprints remain embedded in the native PCB; no synthetic local footprint libraries were generated.
IMPORTANT: no original schematic parity, qualified multilayer stackup, LPDDR4 signal integrity,
power distribution, memory-controller training or physical hardware verification was performed.
This archive must NOT be described as a verified manufacturable LPDDR4 device.
